package com.personal.personal_accounts_manager

import io.flutter.embedding.android.FlutterFragmentActivity

// FlutterFragmentActivity is required by local_auth (biometric app lock).
class MainActivity : FlutterFragmentActivity()
