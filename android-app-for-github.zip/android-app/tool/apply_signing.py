"""Adds a release signingConfig (reading android/key.properties) to the Flutter-generated
android/app/build.gradle.kts. Used by CI and usable locally:  python3 tool/apply_signing.py android/app/build.gradle.kts"""
import re, sys
path = sys.argv[1]
s = open(path, encoding='utf-8').read()
if 'keystoreProperties' in s:
    print('Signing already configured'); sys.exit(0)
header = '''val keystoreProperties = java.util.Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(java.io.FileInputStream(keystorePropertiesFile))
}

'''
# insert after the plugins { } block
m = re.search(r'plugins\s*\{[^}]*\}\s*', s)
s = s[:m.end()] + '\n' + header + s[m.end():] if m else header + s
signing = '''
    signingConfigs {
        create("release") {
            keyAlias = keystoreProperties["keyAlias"] as String
            keyPassword = keystoreProperties["keyPassword"] as String
            storeFile = file(keystoreProperties["storeFile"] as String)
            storePassword = keystoreProperties["storePassword"] as String
        }
    }
'''
s = re.sub(r'(android\s*\{)', r'\1' + signing.replace('\\', '\\\\'), s, count=1)
s = s.replace('signingConfig = signingConfigs.getByName("debug")', 'signingConfig = signingConfigs.getByName("release")')
open(path, 'w', encoding='utf-8').write(s)
print('Release signing applied to', path)
