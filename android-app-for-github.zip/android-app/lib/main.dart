import 'dart:async';

import 'package:flutter/material.dart';

import 'core/api.dart';
import 'core/data.dart';
import 'core/outbox.dart';
import 'core/session.dart';
import 'screens/home_shell.dart';
import 'screens/lock_screen.dart';
import 'screens/login_screen.dart';
import 'widgets/common.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Session.instance.load();
  await Outbox.instance.load();
  runApp(const PamApp());
}

class PamApp extends StatelessWidget {
  const PamApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Personal Accounts Manager',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: brand,
        scaffoldBackgroundColor: const Color(0xFFF4F6FA),
      ),
      home: const AppGate(),
    );
  }
}

/// Decides between login, lock screen and the app; enforces the inactivity timeout,
/// triggers background sync and reacts to revoked/expired sessions.
class AppGate extends StatefulWidget {
  const AppGate({super.key});
  @override
  State<AppGate> createState() => _AppGateState();
}

class _AppGateState extends State<AppGate> with WidgetsBindingObserver {
  Timer? _timer;
  bool _metaLoaded = false;
  String? _metaError;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    Api.instance.onUnauthorized = () async {
      await Session.instance.clearLogin(wipeCache: false);
    };
    // On a cold start with a PIN configured, the app starts locked.
    if (Session.instance.loggedIn && !Session.instance.pinSet) {
      // No PIN configured: rely on the server token's idle timeout – if it expired, the
      // first request returns 401 and the user is sent to the login screen.
      Session.instance.unlock();
    }
    Session.instance.addListener(_onSession);
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => _tick());
    if (Session.instance.loggedIn) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _afterLogin());
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    Session.instance.removeListener(_onSession);
    _timer?.cancel();
    super.dispose();
  }

  void _onSession() {
    if (mounted) setState(() {});
  }

  void _tick() {
    final s = Session.instance;
    if (!s.loggedIn || !s.unlocked) return;
    if (s.idleExpired) {
      _expire();
    } else if (Outbox.instance.pendingCount > 0) {
      Outbox.instance.sync();
    }
  }

  void _expire() {
    final s = Session.instance;
    if (s.pinSet) {
      s.lock();
    } else {
      s.clearLogin(wipeCache: false);
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final s = Session.instance;
    if (state == AppLifecycleState.resumed) {
      if (s.loggedIn && s.unlocked && s.idleExpired) {
        _expire();
      } else if (s.loggedIn && s.unlocked) {
        Outbox.instance.sync();
      }
    }
  }

  Future<void> _afterLogin() async {
    setState(() {
      _metaLoaded = false;
      _metaError = null;
    });
    try {
      await AppData.instance.load();
      setState(() => _metaLoaded = true);
      Outbox.instance.sync();
      if (AppData.instance.settings['require_pin_lock'] == true && !Session.instance.pinSet && mounted) {
        WidgetsBinding.instance.addPostFrameCallback((_) => setupPin(context, force: true));
      }
    } on ApiException catch (e) {
      setState(() => _metaError = e.message);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = Session.instance;
    if (!s.loggedIn) {
      return LoginScreen(onLoggedIn: _afterLogin);
    }
    if (!s.unlocked) {
      return const LockScreen();
    }
    if (!_metaLoaded) {
      return Scaffold(
        body: _metaError != null
            ? ErrorView(_metaError!, onRetry: _afterLogin)
            : const Center(child: CircularProgressIndicator()),
      );
    }
    return Listener(
      behavior: HitTestBehavior.translucent,
      onPointerDown: (_) => s.touch(),
      child: const HomeShell(),
    );
  }
}
