import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/data.dart';
import '../core/format.dart';
import '../core/outbox.dart';
import '../core/session.dart';
import '../widgets/common.dart';
import 'lock_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool bioAvailable = false;

  @override
  void initState() {
    super.initState();
    biometricAvailable().then((v) {
      if (mounted) setState(() => bioAvailable = v);
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = Session.instance;
    final settings = AppData.instance.settings;
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: AnimatedBuilder(
        animation: Listenable.merge([s, Outbox.instance]),
        builder: (context, _) => ListView(children: [
          ListTile(
            leading: const CircleAvatar(child: Icon(Icons.person)),
            title: Text((s.user['display_name'] ?? s.user['login'] ?? '').toString()),
            subtitle: Text('${s.user['email'] ?? ''}\n${s.site ?? ''}'),
            isThreeLine: true,
          ),
          const Divider(),
          const _Header('Security'),
          ListTile(
            leading: const Icon(Icons.pin),
            title: Text(s.pinSet ? 'Change app PIN' : 'Set app PIN'),
            subtitle: Text(settings['require_pin_lock'] == true ? 'Required by your administrator settings' : 'Optional app lock'),
            onTap: () => setupPin(context),
          ),
          if (s.pinSet && settings['require_pin_lock'] != true)
            ListTile(
              leading: const Icon(Icons.no_encryption),
              title: const Text('Remove app PIN'),
              onTap: () async {
                if (await confirmDialog(context, 'Remove PIN?', 'The app will no longer be locked with a PIN.')) await s.removePin();
              },
            ),
          SwitchListTile(
            secondary: const Icon(Icons.fingerprint),
            title: const Text('Unlock with fingerprint / face'),
            subtitle: Text(!bioAvailable ? 'Not available on this device' : (!s.pinSet ? 'Set a PIN first (fallback)' : 'Uses the device biometrics')),
            value: s.biometricEnabled,
            onChanged: (bioAvailable && s.pinSet) ? (v) => s.setBiometric(v) : null,
          ),
          ListTile(
            leading: const Icon(Icons.timer_outlined),
            title: const Text('Automatic lock / session timeout'),
            subtitle: Text('${s.idleMinutes} minutes of inactivity (configured on the website)'),
          ),
          const Divider(),
          const _Header('Synchronisation'),
          ListTile(
            leading: Icon(Outbox.instance.attentionCount > 0 ? Icons.error_outline : Icons.cloud_done_outlined, color: Outbox.instance.attentionCount > 0 ? bad : null),
            title: const Text('Unsynced entries'),
            subtitle: Text('${Outbox.instance.pendingCount} waiting · ${Outbox.instance.attentionCount} need attention${Outbox.instance.lastSync != null ? '\nLast sync ${Outbox.instance.lastSync}' : ''}'),
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SyncScreen())),
          ),
          ListTile(
            leading: const Icon(Icons.refresh),
            title: const Text('Refresh employees, categories & accounts'),
            onTap: () async {
              try {
                await AppData.instance.load();
                showSnack(context, AppData.instance.fromCache ? 'Offline – using saved data' : 'Reference data refreshed');
              } on ApiException catch (e) {
                showSnack(context, e.message, error: true);
              }
            },
          ),
          const Divider(),
          const _Header('Account'),
          ListTile(
            leading: const Icon(Icons.devices_other),
            title: const Text('Sign out all devices'),
            subtitle: const Text('Revokes every Android app session, including this one'),
            onTap: () async {
              if (!await confirmDialog(context, 'Sign out all devices?', 'All app sessions will be revoked.', ok: 'Revoke all', danger: true)) return;
              try {
                await Api.instance.post('auth/revoke-all');
              } catch (_) {}
              await s.clearLogin();
              if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
            },
          ),
          ListTile(
            leading: const Icon(Icons.logout, color: bad),
            title: const Text('Log out', style: TextStyle(color: bad)),
            onTap: () async {
              final pending = Outbox.instance.items.length;
              if (!await confirmDialog(context, 'Log out?', pending > 0 ? 'You have $pending unsynced entr${pending == 1 ? 'y' : 'ies'}. They stay on this phone and will sync after you log in again.' : 'You will need your password to log in again.', ok: 'Log out')) return;
              try {
                await Api.instance.post('auth/logout');
              } catch (_) {}
              await s.clearLogin();
              if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('Personal Accounts Manager'),
            subtitle: Text('App 1.0.0 · Server ${AppData.instance.meta['version'] ?? '?'} · Currency INR (₹) · Dates DD-MM-YYYY'),
          ),
        ]),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
        child: Text(text.toUpperCase(), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1, color: Colors.black54)),
      );
}

/// Shows entries saved offline. Rejected entries are never dropped silently.
class SyncScreen extends StatelessWidget {
  const SyncScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final o = Outbox.instance;
    return Scaffold(
      appBar: AppBar(title: const Text('Unsynced entries'), actions: [
        IconButton(tooltip: 'Sync now', icon: const Icon(Icons.sync), onPressed: () async {
          final n = await o.sync();
          showSnack(context, n > 0 ? '$n entr${n == 1 ? 'y' : 'ies'} synced' : (o.lastError ?? 'Nothing to sync'));
        }),
      ]),
      body: AnimatedBuilder(
        animation: o,
        builder: (context, _) => o.items.isEmpty
            ? const Center(child: Text('All entries are synchronised.'))
            : ListView(children: [
                if (o.syncing) const LinearProgressIndicator(),
                if (o.lastError != null) Padding(padding: const EdgeInsets.all(12), child: Text('Last attempt: ${o.lastError}', style: const TextStyle(color: warn))),
                for (final i in o.items)
                  Card(
                    margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Expanded(child: Text(i.label, style: const TextStyle(fontWeight: FontWeight.w700))),
                          StatusChip(i.status == 'pending' ? 'Waiting' : 'Needs attention', color: i.status == 'pending' ? warn : bad),
                        ]),
                        Text('Saved ${i.createdAt.toLocal()} · ${dmy(i.body['txn_date'])}${i.body['amount'] != null ? ' · ${inr(i.body['amount'])}' : ''}', style: const TextStyle(fontSize: 12, color: Colors.black54)),
                        if (i.error != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(i.error!, style: const TextStyle(color: bad))),
                        if (i.status == 'attention')
                          Wrap(spacing: 8, children: [
                            if (i.errorCode == 'overpayment_confirmation_required') ...[
                              TextButton(onPressed: () => o.retry(i.id, extra: {'overpayment_action': 'split'}), child: const Text('Excess as advance')),
                              TextButton(onPressed: () => o.retry(i.id, extra: {'overpayment_action': 'advance'}), child: const Text('All as advance')),
                            ],
                            if (i.errorCode == 'duplicate_work_record') TextButton(onPressed: () => o.retry(i.id, extra: {'allow_multiple_sessions': true}), child: const Text('Add as extra session')),
                            TextButton(onPressed: () => o.retry(i.id), child: const Text('Retry')),
                            TextButton(
                              onPressed: () async {
                                if (await confirmDialog(context, 'Discard entry?', 'This entry was never saved on the server. Discarding deletes it permanently from this phone.', ok: 'Discard', danger: true)) {
                                  await o.discard(i.id);
                                }
                              },
                              child: const Text('Discard', style: TextStyle(color: bad)),
                            ),
                          ]),
                      ]),
                    ),
                  ),
              ]),
      ),
    );
  }
}
