import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/format.dart';
import '../widgets/common.dart';
import '../widgets/report_view.dart';
import 'entry_form.dart';
import 'txn_list.dart';

/// Payments tab: payments, working days, advances and outstanding balances.
class PaymentsScreen extends StatelessWidget {
  const PaymentsScreen({super.key, this.initialTab = 0});
  final int initialTab;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      initialIndex: initialTab,
      child: Column(children: [
        const Material(
          color: Colors.white,
          child: TabBar(isScrollable: true, tabs: [Tab(text: 'Payments'), Tab(text: 'Working days'), Tab(text: 'Advances'), Tab(text: 'Outstanding')]),
        ),
        Expanded(
          child: TabBarView(children: [
            const TxnList(type: 'payment'),
            const TxnList(type: 'work'),
            const AdvancesTab(),
            const OutstandingTab(),
          ]),
        ),
      ]),
    );
  }
}

class AdvancesTab extends StatefulWidget {
  const AdvancesTab({super.key});
  @override
  State<AdvancesTab> createState() => _AdvancesTabState();
}

class _AdvancesTabState extends State<AdvancesTab> {
  final _issued = GlobalKey<TxnListState>();
  final _rec = GlobalKey<TxnListState>();

  void _refresh() {
    _issued.currentState?.reload();
    _rec.currentState?.reload();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: const PreferredSize(
          preferredSize: Size.fromHeight(44),
          child: Material(color: Color(0xFFF7F9FC), child: TabBar(tabs: [Tab(text: 'Advances issued'), Tab(text: 'Recoveries')])),
        ),
        body: TabBarView(children: [
          TxnList(key: _issued, type: 'payment', paymentType: 'advance', embedded: true),
          TxnList(key: _rec, type: 'recovery', embedded: true),
        ]),
        floatingActionButton: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.end, children: [
          FloatingActionButton.extended(
            heroTag: 'fab_adv_rec',
            onPressed: () async {
              if (await openEntry(context, 'recovery')) _refresh();
            },
            icon: const Icon(Icons.south_west),
            label: const Text('Record recovery'),
          ),
          const SizedBox(height: 10),
          FloatingActionButton.extended(
            heroTag: 'fab_adv_issue',
            onPressed: () async {
              if (await openEntry(context, 'payment', preset: {'payment_type': 'advance'})) _refresh();
            },
            icon: const Icon(Icons.north_east),
            label: const Text('Issue advance'),
          ),
        ]),
      ),
    );
  }
}

class OutstandingTab extends StatefulWidget {
  const OutstandingTab({super.key});
  @override
  State<OutstandingTab> createState() => _OutstandingTabState();
}

class _OutstandingTabState extends State<OutstandingTab> {
  String asOf = todayYmd();
  Map<String, dynamic>? t;
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = Map<String, dynamic>.from(await Api.instance.get('outstanding', {'as_of': asOf}) as Map);
      setState(() {
        t = r;
        error = null;
      });
    } on ApiException catch (e) {
      setState(() => error = e.message);
    }
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: load,
      child: ListView(padding: const EdgeInsets.all(12), children: [
        PickerField(label: 'As of date', icon: Icons.calendar_month, text: dmy(asOf), onTap: () async {
          final d = await pickDate(context, asOf);
          if (d != null) {
            setState(() => asOf = d);
            load();
          }
        }),
        const SizedBox(height: 8),
        const Text('Earned wages not yet paid (liability) and unrecovered advances (receivable) are shown separately.', style: TextStyle(color: Colors.black54, fontSize: 12.5)),
        const SizedBox(height: 10),
        if (error != null) ErrorView(error!, onRetry: load),
        if (t != null) ReportView(t!),
      ]),
    );
  }
}
