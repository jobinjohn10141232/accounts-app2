import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/format.dart';
import '../core/session.dart';
import '../widgets/bar_chart.dart';
import '../widgets/common.dart';
import 'entry_form.dart';

const periods = {
  'today': 'Today',
  'yesterday': 'Yesterday',
  'this_week': 'This week',
  'this_month': 'This month',
  'previous_month': 'Previous month',
  'this_year': 'This year',
  'custom': 'Custom range',
};

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key, required this.onOpenTab});
  final void Function(int tab) onOpenTab;

  @override
  State<DashboardScreen> createState() => DashboardScreenState();
}

class DashboardScreenState extends State<DashboardScreen> {
  String period = 'this_month';
  String? from;
  String? to;
  Map<String, dynamic>? d;
  String? error;
  bool cached = false;
  bool loading = false;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() {
      loading = true;
      error = null;
    });
    final q = {'period': period, if (period == 'custom') 'from': from, if (period == 'custom') 'to': to};
    try {
      final r = Map<String, dynamic>.from(await Api.instance.get('dashboard', q) as Map);
      await Session.instance.cachePut('dashboard_$period', r);
      setState(() {
        d = r;
        cached = false;
      });
    } on ApiException catch (e) {
      final c = e.isNetwork ? await Session.instance.cacheGet('dashboard_$period') : null;
      setState(() {
        if (c is Map) {
          d = Map<String, dynamic>.from(c);
          cached = true;
        } else {
          error = e.message;
        }
      });
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _pickPeriod(String? p) async {
    if (p == null) return;
    if (p == 'custom') {
      final r = await showDateRangePicker(context: context, firstDate: DateTime(2000), lastDate: DateTime(2100));
      if (r == null) return;
      from = ymd(r.start);
      to = ymd(r.end);
    }
    setState(() => period = p);
    load();
  }

  Widget _quick(IconData i, String label, Future<void> Function() fn) => ActionChip(avatar: Icon(i, size: 18), label: Text(label), onPressed: () async {
        await fn();
      });

  @override
  Widget build(BuildContext context) {
    final data = d;
    return RefreshIndicator(
      onRefresh: load,
      child: ListView(padding: const EdgeInsets.fromLTRB(12, 8, 12, 96), children: [
        Row(children: [
          Expanded(
            child: DropdownButtonFormField<String>(
              value: period,
              isDense: true,
              decoration: const InputDecoration(labelText: 'Period', border: OutlineInputBorder()),
              items: periods.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(),
              onChanged: _pickPeriod,
            ),
          ),
        ]),
        const SizedBox(height: 10),
        Wrap(spacing: 6, runSpacing: 4, children: [
          _quick(Icons.person_add, 'Add Employee', () async {
            if (await openEmployeeForm(context) != null) load();
          }),
          _quick(Icons.event_available, 'Record Working Day', () async {
            if (await openEntry(context, 'work')) load();
          }),
          _quick(Icons.payments, 'Record Employee Payment', () async {
            if (await openEntry(context, 'payment')) load();
          }),
          _quick(Icons.north_east, 'Issue Employee Advance', () async {
            if (await openEntry(context, 'payment', preset: {'payment_type': 'advance'})) load();
          }),
          _quick(Icons.south_west, 'Record Cash Received', () async {
            if (await openEntry(context, 'receipt')) load();
          }),
          _quick(Icons.shopping_cart, 'Record Cash Paid', () async {
            if (await openEntry(context, 'expense')) load();
          }),
          _quick(Icons.hourglass_bottom, 'View Outstanding Payments', () async => widget.onOpenTab(2)),
          _quick(Icons.summarize, 'Generate Report', () async => widget.onOpenTab(4)),
        ]),
        if (cached)
          Container(
            margin: const EdgeInsets.only(top: 8),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: const Color(0xFFFFF4DC), borderRadius: BorderRadius.circular(8)),
            child: const Text('Offline – showing the last saved figures. Pull to refresh when connected.'),
          ),
        if (loading && data == null) const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator())),
        if (error != null && data == null) ErrorView(error!, onRetry: load),
        if (data != null) ..._content(data),
      ]),
    );
  }

  List<Widget> _content(Map<String, dynamic> data) {
    final e = Map<String, dynamic>.from(data['employees'] as Map);
    final p = Map<String, dynamic>.from(data['personal'] as Map);
    final o = Map<String, dynamic>.from(data['overview'] as Map);
    final ch = Map<String, dynamic>.from(data['charts'] as Map);
    final m = Map<String, dynamic>.from(ch['monthly'] as Map);
    List<double> dl(dynamic l) => ((l as List?) ?? const []).map((x) => num0(x)).toList();
    final labels = ((m['labels'] as List?) ?? const []).map((x) => x.toString()).toList();
    final accounts = ((data['accounts'] as List?) ?? const []).map((x) => Map<String, dynamic>.from(x as Map)).toList();
    return [
      Padding(padding: const EdgeInsets.only(top: 8), child: Text('Period ${dmy(data['from'])} to ${dmy(data['to'])}', style: const TextStyle(color: Colors.black54, fontSize: 12.5))),
      const SectionTitle('Employee summary'),
      StatGrid(children: [
        StatCard(title: 'Total employees', value: '${e['total_employees']}', subtitle: '${e['active_employees']} active'),
        StatCard(title: 'Working days', value: qty(e['working_days']), subtitle: 'in period', color: const Color(0xFF2E6AA3)),
        StatCard(title: 'Wages earned', value: inr(e['wages_earned']), subtitle: 'earned (not cash paid)', color: const Color(0xFF2E6AA3)),
        StatCard(title: 'Payments against wages', value: inr(e['payments_against_wages']), subtitle: 'paid in period', color: good),
        StatCard(title: 'Total employee payments', value: inr(e['total_payments_made']), subtitle: 'all payment types', color: good),
        StatCard(title: 'Outstanding wages', value: inr(e['outstanding_wages']), subtitle: 'owed to employees', color: bad, valueColor: num0(e['outstanding_wages']) > 0 ? bad : null),
        StatCard(title: 'Unrecovered advances', value: inr(e['outstanding_advances']), subtitle: 'owed by employees', color: warn),
      ]),
      const SectionTitle('Personal expense summary'),
      StatGrid(children: [
        StatCard(title: 'Cash received', value: inr(p['cash_received']), subtitle: 'in period', color: good, valueColor: good),
        StatCard(title: 'Personal expenses paid', value: inr(p['expenses_paid']), subtitle: 'in period', color: bad),
        StatCard(title: 'Total cash balance', value: inr(p['cash_balance']), subtitle: 'all accounts, period end', color: const Color(0xFF7C3AED)),
        StatCard(title: 'Expenses this month', value: inr(p['month_expenses']), subtitle: p['month_label']?.toString(), color: warn),
      ]),
      const SectionTitle('Financial overview'),
      StatGrid(children: [
        StatCard(title: 'Total money received', value: inr(o['money_received']), color: good),
        StatCard(title: 'Total money paid', value: inr(o['money_paid']), color: bad),
        StatCard(title: 'Employee wages earned', value: inr(o['wages_earned']), subtitle: 'liability created'),
        StatCard(title: 'Employee payments made', value: inr(o['employee_payments']), subtitle: 'cash actually paid', color: good),
        StatCard(title: 'Outstanding wages', value: inr(o['outstanding_wages']), subtitle: 'liability – not a cash payment', color: bad),
        StatCard(title: 'Current recorded balance', value: inr(o['current_balance']), subtitle: 'today', color: const Color(0xFF7C3AED)),
      ]),
      const SectionTitle('Charts'),
      _card('Monthly wages earned vs employee payments', GroupedBarChart(labels: labels, series: [
        ChartSeries('Wages earned', dl(m['wages']), const Color(0xFF2E6AA3)),
        ChartSeries('Employee payments', dl(m['payments']), const Color(0xFF1B9E77)),
      ])),
      _card('Monthly cash received vs cash paid', GroupedBarChart(labels: labels, series: [
        ChartSeries('Received', dl(m['received']), good),
        ChartSeries('Paid', dl(m['paid']), const Color(0xFFDC2626)),
      ])),
      _card('Outstanding wages by employee', ProportionBars(
        color: bad,
        emptyText: 'Nothing outstanding',
        items: ((ch['outstanding'] as List?) ?? const []).map((x) => MapEntry((x as Map)['name'].toString(), num0(x['wages']))).where((x) => x.value > 0).toList(),
      )),
      _card('Expense category breakdown', ProportionBars(
        emptyText: 'No expenses in this period',
        items: ((ch['categories'] as List?) ?? const []).map((x) => MapEntry((x as Map)['name'].toString(), num0(x['value']))).toList(),
      )),
      const SectionTitle('Account balances'),
      Card(
        margin: EdgeInsets.zero,
        child: Column(children: [
          for (final a in accounts) ListTile(dense: true, title: Text(a['name'].toString()), subtitle: Text(a['type'].toString().toUpperCase()), trailing: MoneyText(a['balance'], style: const TextStyle(fontWeight: FontWeight.w700))),
        ]),
      ),
    ];
  }

  Widget _card(String title, Widget child) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            child,
          ]),
        ),
      );
}
