import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';

import '../core/session.dart';
import '../widgets/common.dart';

/// App lock: PIN and/or biometric (fingerprint / face) where the device supports it.
class LockScreen extends StatefulWidget {
  const LockScreen({super.key});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  final _pin = TextEditingController();
  final _auth = LocalAuthentication();
  String? _error;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    if (Session.instance.biometricEnabled) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _biometric());
    }
  }

  Future<void> _biometric() async {
    try {
      final ok = await _auth.authenticate(
        localizedReason: 'Unlock Personal Accounts Manager',
        options: const AuthenticationOptions(stickyAuth: true),
      );
      if (ok) Session.instance.unlock();
    } catch (e) {
      setState(() => _error = 'Biometric unlock unavailable. Use your PIN.');
    }
  }

  Future<void> _submit() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    final ok = await Session.instance.checkPin(_pin.text);
    if (!mounted) return;
    setState(() => _busy = false);
    if (ok) {
      Session.instance.unlock();
    } else {
      _pin.clear();
      setState(() => _error = Session.instance.loggedIn ? 'Incorrect PIN.' : 'Too many wrong PINs – please log in again.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 360),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                const Icon(Icons.lock, size: 56, color: brand),
                const SizedBox(height: 12),
                const Text('Locked', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
                const SizedBox(height: 24),
                TextField(
                  controller: _pin,
                  obscureText: true,
                  keyboardType: TextInputType.number,
                  maxLength: 8,
                  autofocus: !Session.instance.biometricEnabled,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 24, letterSpacing: 8),
                  onSubmitted: (_) => _submit(),
                  decoration: InputDecoration(labelText: 'PIN', errorText: _error, border: const OutlineInputBorder(), counterText: ''),
                ),
                const SizedBox(height: 12),
                FilledButton(onPressed: _busy ? null : _submit, child: const Text('Unlock')),
                if (Session.instance.biometricEnabled)
                  TextButton.icon(onPressed: _biometric, icon: const Icon(Icons.fingerprint), label: const Text('Use fingerprint / face')),
                TextButton(
                  onPressed: () async {
                    if (await confirmDialog(context, 'Log out?', 'You will need your password to log in again. Unsynced entries stay on this phone.')) {
                      await Session.instance.clearLogin();
                    }
                  },
                  child: const Text('Log out instead'),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

/// Set or change the PIN (4–8 digits).
Future<bool> setupPin(BuildContext context, {bool force = false}) async {
  final a = TextEditingController();
  final b = TextEditingController();
  String? err;
  final ok = await showDialog<bool>(
    context: context,
    barrierDismissible: !force,
    builder: (c) => StatefulBuilder(
      builder: (c, set) => AlertDialog(
        title: Text(force ? 'Set an app PIN (required)' : 'Set app PIN'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: a, obscureText: true, keyboardType: TextInputType.number, maxLength: 8, decoration: const InputDecoration(labelText: 'New PIN (4–8 digits)')),
          TextField(controller: b, obscureText: true, keyboardType: TextInputType.number, maxLength: 8, decoration: InputDecoration(labelText: 'Repeat PIN', errorText: err)),
        ]),
        actions: [
          if (!force) TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              if (!RegExp(r'^\d{4,8}$').hasMatch(a.text)) {
                set(() => err = 'Use 4 to 8 digits.');
                return;
              }
              if (a.text != b.text) {
                set(() => err = 'PINs do not match.');
                return;
              }
              await Session.instance.setPin(a.text);
              if (c.mounted) Navigator.pop(c, true);
            },
            child: const Text('Save PIN'),
          ),
        ],
      ),
    ),
  );
  return ok ?? false;
}

Future<bool> biometricAvailable() async {
  try {
    final auth = LocalAuthentication();
    return await auth.isDeviceSupported() && await auth.canCheckBiometrics;
  } catch (_) {
    return false;
  }
}
