import 'package:flutter/material.dart';

import '../core/data.dart';
import '../core/outbox.dart';
import '../widgets/common.dart';
import 'dashboard_screen.dart';
import 'employees_screen.dart';
import 'entry_form.dart';
import 'expenses_screen.dart';
import 'payments_screen.dart';
import 'reports_screen.dart';
import 'settings_screen.dart';

/// Main screen with bottom navigation: Dashboard · Employees · Payments · Expenses · Reports.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int tab = 0;
  int paymentsTab = 0;
  final _dash = GlobalKey<DashboardScreenState>();

  static const titles = ['Dashboard', 'Employees', 'Payments', 'Expenses', 'Reports'];

  void _openTab(int t) {
    setState(() {
      if (t == 2) paymentsTab = 3; // "View outstanding payments" quick action
      tab = t;
    });
  }

  Future<void> _quickAdd() async {
    final a = await showModalBottomSheet<String>(
      context: context,
      builder: (c) => SafeArea(
        child: Wrap(children: [
          const ListTile(title: Text('Quick entry', style: TextStyle(fontWeight: FontWeight.w700))),
          ListTile(leading: const Icon(Icons.event_available), title: const Text('Record working day'), onTap: () => Navigator.pop(c, 'work')),
          ListTile(leading: const Icon(Icons.payments), title: const Text('Record employee payment'), onTap: () => Navigator.pop(c, 'payment')),
          ListTile(leading: const Icon(Icons.north_east), title: const Text('Issue employee advance'), onTap: () => Navigator.pop(c, 'advance')),
          ListTile(leading: const Icon(Icons.south_west), title: const Text('Record cash received'), onTap: () => Navigator.pop(c, 'receipt')),
          ListTile(leading: const Icon(Icons.shopping_cart), title: const Text('Record cash paid'), onTap: () => Navigator.pop(c, 'expense')),
          ListTile(leading: const Icon(Icons.person_add), title: const Text('Add employee'), onTap: () => Navigator.pop(c, 'employee')),
        ]),
      ),
    );
    if (a == null || !mounted) return;
    bool saved;
    if (a == 'employee') {
      saved = await openEmployeeForm(context) != null;
    } else if (a == 'advance') {
      saved = await openEntry(context, 'payment', preset: {'payment_type': 'advance'});
    } else {
      saved = await openEntry(context, a);
    }
    if (saved) _dash.currentState?.load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(titles[tab]),
        actions: [
          AnimatedBuilder(
            animation: Outbox.instance,
            builder: (context, _) {
              final o = Outbox.instance;
              if (o.items.isEmpty) return const SizedBox.shrink();
              return IconButton(
                tooltip: '${o.pendingCount} unsynced, ${o.attentionCount} need attention',
                icon: Badge(
                  label: Text('${o.items.length}'),
                  backgroundColor: o.attentionCount > 0 ? bad : warn,
                  child: Icon(o.syncing ? Icons.sync : Icons.cloud_upload_outlined),
                ),
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SyncScreen())),
              );
            },
          ),
          IconButton(tooltip: 'Quick entry', icon: const Icon(Icons.add_circle_outline), onPressed: _quickAdd),
          IconButton(tooltip: 'Settings', icon: const Icon(Icons.settings_outlined), onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsScreen()))),
        ],
      ),
      body: Column(children: [
        AnimatedBuilder(
          animation: AppData.instance,
          builder: (context, _) => AppData.instance.fromCache
              ? Container(
                  width: double.infinity,
                  color: const Color(0xFFFFF4DC),
                  padding: const EdgeInsets.all(6),
                  child: const Text('Offline mode – new entries are saved on this phone and synced later.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12)),
                )
              : const SizedBox.shrink(),
        ),
        Expanded(
          child: IndexedStack(index: tab, children: [
            DashboardScreen(key: _dash, onOpenTab: _openTab),
            const EmployeesScreen(),
            PaymentsScreen(key: ValueKey('pay$paymentsTab'), initialTab: paymentsTab),
            const ExpensesScreen(),
            const ReportsScreen(),
          ]),
        ),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'Employees'),
          NavigationDestination(icon: Icon(Icons.payments_outlined), selectedIcon: Icon(Icons.payments), label: 'Payments'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet), label: 'Expenses'),
          NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'Reports'),
        ],
      ),
    );
  }
}
