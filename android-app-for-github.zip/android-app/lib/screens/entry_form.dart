import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../core/api.dart';
import '../core/data.dart';
import '../core/format.dart';
import '../widgets/common.dart';

/// Transaction types and their REST routes.
const txnRoutes = {
  'work': 'work-records',
  'payment': 'payments',
  'recovery': 'advance-recoveries',
  'receipt': 'receipts',
  'expense': 'expenses',
  'transfer': 'transfers',
  'adjustment': 'adjustments',
};
const txnTitles = {
  'work': 'Work day',
  'payment': 'Employee payment',
  'recovery': 'Advance recovery',
  'receipt': 'Cash received',
  'expense': 'Cash paid',
  'transfer': 'Account transfer',
  'adjustment': 'Balance adjustment',
};

/// Opens the entry form; returns true when something was saved.
Future<bool> openEntry(BuildContext context, String type, {Map<String, dynamic>? record, Map<String, dynamic>? preset}) async {
  final r = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => EntryForm(type: type, record: record, preset: preset ?? const {})));
  return r ?? false;
}

class EntryForm extends StatefulWidget {
  const EntryForm({super.key, required this.type, this.record, this.preset = const {}});
  final String type;
  final Map<String, dynamic>? record;
  final Map<String, dynamic> preset;

  @override
  State<EntryForm> createState() => _EntryFormState();
}

class _EntryFormState extends State<EntryForm> {
  final Map<String, dynamic> v = {};
  final Map<String, TextEditingController> c = {};
  final Map<String, String?> errors = {};
  bool busy = false;
  bool rateTouched = false;
  String? info;
  bool infoWarn = false;
  File? receipt;
  Timer? _debounce;

  bool get editing => widget.record != null;
  String get type => widget.type;
  AppData get data => AppData.instance;

  static const _textKeys = [
    'day_qty', 'wage_rate', 'hours_worked', 'overtime_hours', 'overtime_earnings', 'additional_earnings', 'deductions',
    'amount', 'reference', 'description', 'notes', 'received_from', 'paid_to', 'actual_balance', 'reason', 'correction_reason',
  ];

  @override
  void initState() {
    super.initState();
    final src = {...widget.preset, ...?widget.record};
    v.addAll(src);
    v['txn_date'] ??= todayYmd();
    if (type == 'work') v['work_status'] ??= 'full';
    if (type == 'payment') v['payment_type'] ??= 'wage';
    if (['payment', 'receipt', 'expense'].contains(type)) v['payment_method'] ??= 'cash';
    if (type == 'recovery') v['recovery_method'] ??= 'wage_offset';
    for (final k in _textKeys) {
      var init = src[k]?.toString() ?? '';
      if (k == 'day_qty' && init.isEmpty && type == 'work') init = '1';
      c[k] = TextEditingController(text: init);
    }
    if (type == 'payment' && !editing && v['account_id'] == null && data.settings['auto_link_employee_payments'] == true) {
      v['account_id'] = data.defaultAccountFor(v['payment_method'].toString());
    }
    if (editing) rateTouched = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (type == 'work') _fetchRate();
      if (type == 'payment') _precheck();
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    for (final x in c.values) {
      x.dispose();
    }
    super.dispose();
  }

  /* ---------------- dynamic behaviour ---------------- */

  Future<void> _fetchRate() async {
    if (rateTouched || v['employee_id'] == null) return;
    try {
      final r = await Api.instance.get('employees/${v['employee_id']}/wage-rate', {'date': v['txn_date']});
      if (!mounted) return;
      setState(() => c['wage_rate']!.text = (r as Map)['wage_rate'].toString());
    } on ApiException {
      final e = data.employee(v['employee_id']);
      if (e != null && mounted) setState(() => c['wage_rate']!.text = e['daily_wage'].toString());
    }
  }

  void _precheck() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 400), () async {
      if (type != 'payment' || v['employee_id'] == null || c['amount']!.text.isEmpty) return;
      if (!['wage', 'final_settlement'].contains(v['payment_type'])) {
        setState(() => info = null);
        return;
      }
      try {
        final r = Map<String, dynamic>.from(await Api.instance.post('payments/check', {
          'employee_id': v['employee_id'],
          'txn_date': v['txn_date'],
          'amount': c['amount']!.text,
          if (editing) 'id': widget.record!['id'],
        }) as Map);
        if (!mounted) return;
        setState(() {
          infoWarn = r['exceeds'] == true;
          info = 'Outstanding earned wages on ${dmy(v['txn_date'])}: ${inr(r['outstanding_wages'])}\nUnrecovered advance: ${inr(r['outstanding_advance'])}'
              '${r['exceeds'] == true ? '\nThis payment is ${inr(r['excess'])} more than outstanding wages – you will be asked how to record the excess.' : ''}';
        });
      } catch (_) {
        // offline – the server re-checks on sync
      }
    });
  }

  String get _workCalc {
    final status = v['work_status'];
    final q = status == 'half' ? 0.5 : status == 'absent' ? 0.0 : num0(c['day_qty']!.text);
    final base = (q * num0(c['wage_rate']!.text) * 100).round() / 100;
    final net = base + num0(c['additional_earnings']!.text) + num0(c['overtime_earnings']!.text) - num0(c['deductions']!.text);
    return 'Base wages: ${inr(base.toStringAsFixed(2))}    Net earnings: ${inr(net.toStringAsFixed(2))}';
  }

  /* ---------------- field widgets ---------------- */

  Widget _gap() => const SizedBox(height: 12);

  Widget _text(String k, String label, {bool required = false, TextInputType? kb, int lines = 1, ValueChanged<String>? onChanged, String? hint}) {
    return TextField(
      controller: c[k],
      keyboardType: kb,
      maxLines: lines,
      minLines: 1,
      onChanged: (s) {
        setState(() => errors[k] = null);
        onChanged?.call(s);
      },
      decoration: InputDecoration(labelText: required ? '$label *' : label, helperText: hint, errorText: errors[k], border: const OutlineInputBorder()),
    );
  }

  Widget _money(String k, String label, {bool required = false, ValueChanged<String>? onChanged, bool negative = false}) =>
      _text(k, label, required: required, kb: TextInputType.numberWithOptions(decimal: true, signed: negative), onChanged: onChanged);

  Widget _date(String k, String label) => PickerField(
        label: label,
        required: true,
        icon: Icons.calendar_month,
        text: dmy(v[k]),
        errorText: errors[k],
        onTap: () async {
          final d = await pickDate(context, v[k]?.toString());
          if (d != null) {
            setState(() => v[k] = d);
            if (type == 'work') {
              if (!editing) rateTouched = false;
              _fetchRate();
            }
            if (type == 'payment') _precheck();
          }
        },
      );

  Widget _dropdown(String k, String label, Map<String, String> options, {ValueChanged<String?>? onChanged}) {
    final cur = v[k]?.toString();
    return DropdownButtonFormField<String>(
      value: options.containsKey(cur) ? cur : null,
      isExpanded: true,
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder(), errorText: errors[k]),
      items: options.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value, overflow: TextOverflow.ellipsis))).toList(),
      onChanged: (x) {
        setState(() {
          v[k] = x;
          errors[k] = null;
        });
        onChanged?.call(x);
      },
    );
  }

  Widget _account(String k, String label, {String? noneLabel}) {
    final opts = <String, String>{if (noneLabel != null) '': noneLabel};
    for (final a in data.accounts()) {
      opts[a['id'].toString()] = '${a['name']} (${a['account_type']})';
    }
    final cur = v[k] == null ? '' : v[k].toString();
    return DropdownButtonFormField<String>(
      value: opts.containsKey(cur) ? cur : null,
      isExpanded: true,
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder(), errorText: errors[k]),
      items: opts.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value, overflow: TextOverflow.ellipsis))).toList(),
      onChanged: (x) => setState(() {
        v[k] = (x == null || x.isEmpty) ? null : int.tryParse(x);
        errors[k] = null;
      }),
    );
  }

  Widget _employee() {
    final e = data.employee(v['employee_id']);
    return PickerField(
      label: 'Employee',
      required: true,
      text: e == null ? '' : '${e['name']} · ${e['employee_code']}',
      errorText: errors['employee_id'],
      onTap: () async {
        final items = data.employees(includeInactive: editing || type == 'recovery').map((x) => {'id': x['id'], 'label': x['name'], 'sub': '${x['employee_code']}${(x['mobile'] ?? '').toString().isNotEmpty ? ' · ${x['mobile']}' : ''}'}).toList();
        final p = await pickItem(context, 'employees', items);
        if (p != null) {
          setState(() {
            v['employee_id'] = p['id'];
            errors['employee_id'] = null;
          });
          if (type == 'work') {
            if (!editing) rateTouched = false;
            _fetchRate();
          }
          if (type == 'payment') _precheck();
        }
      },
    );
  }

  Widget _category(String catType, {bool required = false}) {
    final all = data.categories(catType, includeInactive: true);
    Map<String, dynamic>? cur;
    for (final x in all) {
      if (x['id'].toString() == v['category_id']?.toString()) cur = x;
    }
    return PickerField(
      label: catType == 'expense' ? 'Expense category' : 'Income / receipt category',
      required: required,
      text: cur == null ? '' : cur['name'].toString(),
      errorText: errors['category_id'],
      onTap: () async {
        final items = data.categories(catType).map((x) => {'id': x['id'], 'label': x['name']}).toList();
        final p = await pickItem(context, 'categories', items);
        if (p != null) setState(() => v['category_id'] = p['id']);
      },
    );
  }

  /* ---------------- forms per type ---------------- */

  List<Widget> _fields() {
    switch (type) {
      case 'work':
        final status = v['work_status'];
        return [
          _employee(), _gap(), _date('txn_date', 'Work date'), _gap(),
          _dropdown('work_status', 'Working status', workStatusLabels, onChanged: (s) {
            if (s == 'half') c['day_qty']!.text = '0.50';
            if (s == 'absent') c['day_qty']!.text = '0';
            if ((s == 'full' || s == 'paid_leave') && num0(c['day_qty']!.text) == 0) c['day_qty']!.text = '1';
            setState(() {});
          }), _gap(),
          if (status == 'custom' || status == 'full' || status == 'paid_leave') ...[_text('day_qty', 'Number of working days', kb: TextInputType.numberWithOptions(decimal: true), hint: 'Full = 1.00 · Half = 0.50 · Quarter = 0.25', onChanged: (_) => setState(() {})), _gap()],
          _money('wage_rate', 'Daily wage rate (₹)', onChanged: (_) => setState(() => rateTouched = true)), _gap(),
          Row(children: [
            Expanded(child: _text('hours_worked', 'Hours (optional)', kb: TextInputType.numberWithOptions(decimal: true))),
            const SizedBox(width: 8),
            Expanded(child: _text('overtime_hours', 'Overtime hours', kb: TextInputType.numberWithOptions(decimal: true))),
          ]), _gap(),
          _money('overtime_earnings', 'Approved overtime earnings (₹)', onChanged: (_) => setState(() {})), _gap(),
          _money('additional_earnings', 'Additional earnings (₹)', onChanged: (_) => setState(() {})), _gap(),
          _money('deductions', 'Deductions (₹)', onChanged: (_) => setState(() {})), _gap(),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: const Color(0xFFE8F0F8), borderRadius: BorderRadius.circular(8)),
            child: Text(_workCalc, style: const TextStyle(fontWeight: FontWeight.w600)),
          ), _gap(),
          _text('description', 'Work description'), _gap(),
          _text('notes', 'Notes', lines: 3),
          if (!editing)
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              value: v['allow_multiple_sessions'] == true,
              onChanged: (b) => setState(() => v['allow_multiple_sessions'] = b),
              title: const Text('Additional work session on the same date'),
            ),
        ];
      case 'payment':
        return [
          _employee(), _gap(), _date('txn_date', 'Payment date'), _gap(),
          _money('amount', 'Payment amount (₹)', required: true, onChanged: (_) => _precheck()), _gap(),
          if (info != null) ...[
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: infoWarn ? const Color(0xFFFFF4DC) : const Color(0xFFE8F0F8), borderRadius: BorderRadius.circular(8)),
              child: Text(info!, style: const TextStyle(fontSize: 13)),
            ),
            _gap(),
          ],
          _dropdown('payment_type', 'Payment type', paymentTypeLabels, onChanged: (_) => _precheck()), _gap(),
          _dropdown('payment_method', 'Payment method', methodLabels, onChanged: (m) {
            if (!editing && data.settings['auto_link_employee_payments'] == true && m != null) {
              setState(() => v['account_id'] = data.defaultAccountFor(m));
            }
          }), _gap(),
          _account('account_id', 'Paid from account (cash ledger)', noneLabel: 'Not linked to cash ledger'), _gap(),
          _text('reference', 'Payment reference (UPI / bank)'), _gap(),
          _text('description', 'Description'), _gap(),
          _text('notes', 'Notes', lines: 3),
        ];
      case 'recovery':
        return [
          _employee(), _gap(), _date('txn_date', 'Recovery date'), _gap(),
          _money('amount', 'Amount recovered (₹)', required: true), _gap(),
          _dropdown('recovery_method', 'Recovery method', recoveryLabels, onChanged: (_) => setState(() {})), _gap(),
          const Text('“Recovered from wages” applies the advance against earned wages (no cash moves). “Repaid in cash” means the employee returned money.', style: TextStyle(fontSize: 12, color: Colors.black54)),
          _gap(),
          if (v['recovery_method'] == 'cash_repayment') ...[_account('account_id', 'Received into account'), _gap()],
          _text('description', 'Description'), _gap(),
          _text('notes', 'Notes', lines: 3),
        ];
      case 'receipt':
        return [
          _date('txn_date', 'Date received'), _gap(),
          _money('amount', 'Amount (₹)', required: true), _gap(),
          _text('received_from', 'Received from'), _gap(),
          _category('income'), _gap(),
          _dropdown('payment_method', 'Payment method', methodLabels), _gap(),
          _account('account_id', 'Into account', noneLabel: 'Default for payment method'), _gap(),
          _text('reference', 'Reference number'), _gap(),
          _text('description', 'Description'), _gap(),
          _text('notes', 'Notes', lines: 3),
        ];
      case 'expense':
        return [
          _date('txn_date', 'Payment date'), _gap(),
          _category('expense', required: true), _gap(),
          _money('amount', 'Amount paid (₹)', required: true), _gap(),
          _text('paid_to', 'Paid to'), _gap(),
          _dropdown('payment_method', 'Payment method', methodLabels), _gap(),
          _account('account_id', 'From account', noneLabel: 'Default for payment method'), _gap(),
          _text('reference', 'Reference number'), _gap(),
          _text('description', 'Description'), _gap(),
          Row(children: [
            Expanded(child: Text(receipt == null ? (v['attachment_id'] != null ? 'Receipt attached' : 'No receipt attached') : 'Receipt: ${receipt!.path.split('/').last}', style: const TextStyle(color: Colors.black54))),
            IconButton(tooltip: 'Take photo', icon: const Icon(Icons.photo_camera), onPressed: () => _pickReceipt(ImageSource.camera)),
            IconButton(tooltip: 'Choose image', icon: const Icon(Icons.photo_library), onPressed: () => _pickReceipt(ImageSource.gallery)),
          ]),
          _gap(),
          _text('notes', 'Notes', lines: 3),
        ];
      case 'transfer':
        return [
          _date('txn_date', 'Transfer date'), _gap(),
          _account('from_account_id', 'From account *'), _gap(),
          _account('to_account_id', 'To account *'), _gap(),
          _money('amount', 'Amount (₹)', required: true), _gap(),
          _text('reference', 'Reference'), _gap(),
          _text('description', 'Description'), _gap(),
          _text('notes', 'Notes', lines: 3),
        ];
      case 'adjustment':
        return [
          _account('account_id', 'Account *'), _gap(),
          _date('txn_date', 'Date'), _gap(),
          _money('actual_balance', 'Actual balance counted / per statement (₹)', required: true, negative: true), _gap(),
          _text('reason', 'Reason for adjustment', required: true, lines: 2),
        ];
    }
    return [];
  }

  Future<void> _pickReceipt(ImageSource src) async {
    final x = await ImagePicker().pickImage(source: src, maxWidth: 2000, imageQuality: 80);
    if (x != null) setState(() => receipt = File(x.path));
  }

  /* ---------------- submit ---------------- */

  bool _validate() {
    errors.clear();
    void need(String k, String msg) {
      final val = c.containsKey(k) && !['employee_id', 'category_id', 'account_id', 'from_account_id', 'to_account_id'].contains(k) ? c[k]!.text.trim() : v[k];
      if (val == null || val.toString().isEmpty) errors[k] = msg;
    }

    if (['work', 'payment', 'recovery'].contains(type)) need('employee_id', 'Select an employee');
    if (['payment', 'recovery', 'receipt', 'expense', 'transfer'].contains(type)) {
      need('amount', 'Required');
      if (c['amount']!.text.isNotEmpty && !validAmount(c['amount']!.text)) errors['amount'] = 'Enter an amount with up to 2 decimals';
    }
    if (type == 'expense') need('category_id', 'Select a category');
    if (type == 'transfer') {
      need('from_account_id', 'Required');
      need('to_account_id', 'Required');
      if (v['from_account_id'] != null && v['from_account_id'] == v['to_account_id']) errors['to_account_id'] = 'Choose a different account';
    }
    if (type == 'adjustment') {
      need('account_id', 'Required');
      need('actual_balance', 'Required');
      need('reason', 'Required');
    }
    if (type == 'recovery' && v['recovery_method'] == 'cash_repayment') need('account_id', 'Required');
    for (final k in ['wage_rate', 'overtime_earnings', 'additional_earnings', 'deductions']) {
      if (type == 'work' && c[k]!.text.isNotEmpty && !validAmount(c[k]!.text)) errors[k] = 'Invalid amount';
    }
    setState(() {});
    return errors.isEmpty;
  }

  Map<String, dynamic> _body() {
    final b = <String, dynamic>{'txn_date': v['txn_date']};
    void put(String k) {
      final t = c[k]?.text.trim();
      if (t != null && t.isNotEmpty) b[k] = t;
    }

    switch (type) {
      case 'work':
        b.addAll({'employee_id': v['employee_id'], 'work_status': v['work_status']});
        for (final k in ['day_qty', 'wage_rate', 'hours_worked', 'overtime_hours', 'overtime_earnings', 'additional_earnings', 'deductions', 'description', 'notes']) {
          put(k);
        }
        if (v['allow_multiple_sessions'] == true) b['allow_multiple_sessions'] = true;
        break;
      case 'payment':
        b.addAll({'employee_id': v['employee_id'], 'payment_type': v['payment_type'], 'payment_method': v['payment_method'], 'account_id': v['account_id'] ?? ''});
        for (final k in ['amount', 'reference', 'description', 'notes']) {
          put(k);
        }
        break;
      case 'recovery':
        b.addAll({'employee_id': v['employee_id'], 'recovery_method': v['recovery_method']});
        if (v['recovery_method'] == 'cash_repayment') b['account_id'] = v['account_id'];
        for (final k in ['amount', 'description', 'notes']) {
          put(k);
        }
        break;
      case 'receipt':
      case 'expense':
        b.addAll({'payment_method': v['payment_method'], 'category_id': v['category_id'], 'account_id': v['account_id'] ?? ''});
        for (final k in ['amount', 'received_from', 'paid_to', 'reference', 'description', 'notes']) {
          put(k);
        }
        if (v['attachment_id'] != null) b['attachment_id'] = v['attachment_id'];
        break;
      case 'transfer':
        b.addAll({'from_account_id': v['from_account_id'], 'to_account_id': v['to_account_id']});
        for (final k in ['amount', 'reference', 'description', 'notes']) {
          put(k);
        }
        break;
      case 'adjustment':
        b['account_id'] = v['account_id'];
        put('actual_balance');
        put('reason');
        break;
    }
    if (editing) {
      final r = c['correction_reason']!.text.trim();
      if (r.isNotEmpty) b['reason'] = r;
      if (type == 'adjustment') b['reason'] = c['reason']!.text.trim();
    }
    return b;
  }

  Future<void> _save({bool another = false}) async {
    if (!_validate()) return;
    setState(() => busy = true);
    try {
      if (receipt != null) {
        try {
          final a = await Api.instance.uploadAttachment(receipt!);
          v['attachment_id'] = a['id'];
        } on ApiException catch (e) {
          showSnack(context, 'Receipt upload failed: ${e.message}. Saving without it.', error: true);
        }
      }
      final path = txnRoutes[type]! + (editing ? '/${widget.record!['id']}' : '');
      final res = await submitEntry(context, path: path, body: _body(), label: txnTitles[type]!, method: editing ? 'PUT' : 'POST');
      if (res == null || !mounted) return;
      if (another) {
        Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (_) => EntryForm(type: type, preset: {
            'txn_date': v['txn_date'],
            if (type == 'work') 'work_status': v['work_status'],
            if (['receipt', 'expense'].contains(type)) 'payment_method': v['payment_method'],
          }),
        ));
      } else {
        Navigator.of(context).pop(true);
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${editing ? 'Edit' : 'New'} ${txnTitles[type]!.toLowerCase()}')),
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(16), children: [
          if (editing) ...[
            Text('Editing ${widget.record!['txn_id']} – the previous values are kept in the audit log.', style: const TextStyle(color: Colors.black54)),
            _gap(),
          ],
          ..._fields(),
          if (editing && type != 'adjustment') ...[_gap(), _text('correction_reason', 'Reason for correction (audit log)')],
          const SizedBox(height: 20),
          FilledButton(onPressed: busy ? null : () => _save(), style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)), child: Text(busy ? 'Saving…' : 'Save')),
          if (!editing) TextButton(onPressed: busy ? null : () => _save(another: true), child: const Text('Save & add another')),
        ]),
      ),
    );
  }
}

/* ======================= Employee form ======================= */

Future<Map<String, dynamic>?> openEmployeeForm(BuildContext context, {Map<String, dynamic>? employee}) =>
    Navigator.of(context).push<Map<String, dynamic>>(MaterialPageRoute(builder: (_) => EmployeeForm(employee: employee)));

class EmployeeForm extends StatefulWidget {
  const EmployeeForm({super.key, this.employee});
  final Map<String, dynamic>? employee;
  @override
  State<EmployeeForm> createState() => _EmployeeFormState();
}

class _EmployeeFormState extends State<EmployeeForm> {
  static const keys = ['name', 'mobile', 'designation', 'daily_wage', 'emergency_contact', 'address', 'payment_notes', 'notes'];
  final Map<String, TextEditingController> c = {};
  String? joining;
  String? effective;
  String? nameErr;
  String? wageErr;
  bool busy = false;
  final String uuid = newUuid();

  @override
  void initState() {
    super.initState();
    final e = widget.employee ?? {};
    for (final k in keys) {
      c[k] = TextEditingController(text: (e[k] ?? (k == 'daily_wage' ? (AppData.instance.settings['default_daily_wage'] ?? '') : '')).toString());
    }
    joining = e['date_of_joining']?.toString();
    if (widget.employee != null) effective = todayYmd();
  }

  Future<void> _save() async {
    setState(() {
      nameErr = c['name']!.text.trim().isEmpty ? 'Required' : null;
      wageErr = validAmount(c['daily_wage']!.text) ? null : 'Enter a valid amount';
    });
    if (nameErr != null || wageErr != null) return;
    setState(() => busy = true);
    final body = <String, dynamic>{for (final k in keys) k: c[k]!.text.trim(), 'date_of_joining': joining ?? '', if (effective != null) 'wage_effective_from': effective};
    try {
      final r = widget.employee == null
          ? await Api.instance.post('employees', {...body, 'client_uuid': uuid})
          : await Api.instance.put('employees/${widget.employee!['id']}', body);
      await AppData.instance.load();
      if (!mounted) return;
      showSnack(context, 'Employee saved: ${(r as Map)['name']} (${r['employee_code']})');
      Navigator.of(context).pop(Map<String, dynamic>.from(r));
    } on ApiException catch (e) {
      showSnack(context, e.isNetwork ? 'Employees can only be added while online.' : e.message, error: true);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Widget _t(String k, String label, {TextInputType? kb, int lines = 1, String? err}) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(controller: c[k], keyboardType: kb, maxLines: lines, minLines: 1, decoration: InputDecoration(labelText: label, errorText: err, border: const OutlineInputBorder())),
      );

  @override
  Widget build(BuildContext context) {
    final editing = widget.employee != null;
    return Scaffold(
      appBar: AppBar(title: Text(editing ? 'Edit ${widget.employee!['name']}' : 'Add employee')),
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(16), children: [
          _t('name', 'Employee name *', err: nameErr),
          _t('mobile', 'Mobile number', kb: TextInputType.phone),
          _t('designation', 'Job designation / work description'),
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: PickerField(label: 'Date of joining', icon: Icons.calendar_month, text: dmy(joining), onTap: () async {
              final d = await pickDate(context, joining);
              if (d != null) setState(() => joining = d);
            }),
          ),
          _t('daily_wage', 'Daily wage rate (₹) *', kb: const TextInputType.numberWithOptions(decimal: true), err: wageErr),
          if (editing)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: PickerField(label: 'New rate effective from (if changed)', icon: Icons.calendar_month, text: dmy(effective), onTap: () async {
                final d = await pickDate(context, effective);
                if (d != null) setState(() => effective = d);
              }),
            ),
          _t('emergency_contact', 'Emergency contact (optional)'),
          _t('address', 'Address', lines: 3),
          _t('payment_notes', 'Payment notes', lines: 2),
          _t('notes', 'Additional notes', lines: 2),
          FilledButton(onPressed: busy ? null : _save, style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)), child: Text(busy ? 'Saving…' : 'Save employee')),
        ]),
      ),
    );
  }
}
