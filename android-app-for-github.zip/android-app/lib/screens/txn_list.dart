import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/data.dart';
import '../core/format.dart';
import '../widgets/common.dart';
import 'entry_form.dart';

/// Paginated, filterable list of one transaction type with edit / reverse / history actions.
class TxnList extends StatefulWidget {
  const TxnList({super.key, required this.type, this.employeeId, this.paymentType, this.onChanged, this.embedded = false});
  final String type;
  final int? employeeId;
  final String? paymentType;
  final VoidCallback? onChanged;
  final bool embedded;

  @override
  State<TxnList> createState() => TxnListState();
}

class TxnListState extends State<TxnList> {
  final List<Map<String, dynamic>> items = [];
  int page = 1;
  int total = 0;
  String sum = '0.00';
  bool loading = false;
  String? error;
  String search = '';
  String? from;
  String? to;
  bool showReversed = false;
  final _scroll = ScrollController();

  @override
  void initState() {
    super.initState();
    reload();
    _scroll.addListener(() {
      if (_scroll.position.pixels > _scroll.position.maxScrollExtent - 300 && !loading && items.length < total) _load();
    });
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  Future<void> reload() async {
    page = 1;
    items.clear();
    await _load();
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final r = Map<String, dynamic>.from(await Api.instance.get(txnRoutes[widget.type]!, {
        'page': page,
        'per_page': 30,
        'search': search,
        'from': from,
        'to': to,
        'employee_id': widget.employeeId,
        'payment_type': widget.paymentType,
        'include_reversed': showReversed ? 1 : null,
      }) as Map);
      final list = (r['items'] as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
      setState(() {
        items.addAll(list);
        total = int.tryParse(r['total'].toString()) ?? 0;
        sum = r['sum']?.toString() ?? '0.00';
        page++;
      });
    } on ApiException catch (e) {
      setState(() => error = e.message);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  String _title(Map<String, dynamic> x) {
    switch (widget.type) {
      case 'work':
        return '${x['employee_name']} · ${workStatusLabels[x['work_status']] ?? x['work_status']}${(x['session_no'] ?? 1) > 1 ? ' (session ${x['session_no']})' : ''}';
      case 'payment':
        return '${x['employee_name']} · ${paymentTypeLabels[x['payment_type']] ?? x['payment_type']}';
      case 'recovery':
        return '${x['employee_name']} · ${recoveryLabels[x['recovery_method']] ?? ''}';
      case 'receipt':
        return [x['received_from'], x['category_name']].where((s) => s != null && s.toString().isNotEmpty).join(' · ').ifEmpty('Cash received');
      case 'expense':
        return [x['category_name'], x['paid_to']].where((s) => s != null && s.toString().isNotEmpty).join(' · ');
      case 'transfer':
        return '${x['from_account_name']} → ${x['to_account_name']}';
      case 'adjustment':
        return '${x['account_name']} adjustment';
    }
    return x['txn_id'].toString();
  }

  String _subtitle(Map<String, dynamic> x) {
    final parts = <String>[dmy(x['txn_date']), x['txn_id'].toString()];
    if (widget.type == 'work') parts.add('${qty(x['day_qty'])} day × ${inr(x['wage_rate'])}');
    if (x['payment_method'] != null) parts.add(methodLabels[x['payment_method']] ?? '');
    if (x['account_name'] != null && widget.type != 'adjustment') parts.add(x['account_name'].toString());
    if ((x['description'] ?? '').toString().isNotEmpty) parts.add(x['description'].toString());
    if (widget.type == 'adjustment') parts.add(x['reason'].toString());
    return parts.where((s) => s.isNotEmpty).join(' · ');
  }

  String _amount(Map<String, dynamic> x) => widget.type == 'work' ? x['net_earnings'].toString() : x['amount'].toString();

  Future<void> _actions(Map<String, dynamic> x) async {
    final reversed = x['status'] == 'reversed';
    final a = await showModalBottomSheet<String>(
      context: context,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(title: Text(x['txn_id'].toString(), style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text(_subtitle(x))),
          if (!reversed && widget.type != 'adjustment') ListTile(leading: const Icon(Icons.edit), title: const Text('Edit (correction)'), onTap: () => Navigator.pop(c, 'edit')),
          if (!reversed && widget.type == 'work') ListTile(leading: const Icon(Icons.copy), title: const Text('Copy to another date'), onTap: () => Navigator.pop(c, 'copy')),
          ListTile(leading: const Icon(Icons.history), title: const Text('History (audit log)'), onTap: () => Navigator.pop(c, 'history')),
          if (!reversed) ListTile(leading: const Icon(Icons.undo, color: bad), title: const Text('Reverse', style: TextStyle(color: bad)), onTap: () => Navigator.pop(c, 'reverse')),
        ]),
      ),
    );
    if (!mounted || a == null) return;
    final route = txnRoutes[widget.type]!;
    if (a == 'edit') {
      if (await openEntry(context, widget.type, record: x)) _changed();
    } else if (a == 'copy') {
      final d = await pickDate(context, x['txn_date'].toString());
      if (d == null) return;
      final r = await submitEntry(context, path: '$route/${x['id']}/copy', body: {'txn_date': d}, label: 'Copied work record');
      if (r != null) _changed();
    } else if (a == 'reverse') {
      final reason = await askText(context, 'Reverse ${x['txn_id']}', 'Reason for reversal', message: 'The entry stays in the history (marked reversed) and stops counting in all balances.');
      if (reason == null) return;
      try {
        await Api.instance.post('$route/${x['id']}/reverse', {'reason': reason});
        showSnack(context, '${x['txn_id']} reversed');
        _changed();
      } on ApiException catch (e) {
        showSnack(context, e.message, error: true);
      }
    } else if (a == 'history') {
      try {
        final h = Map<String, dynamic>.from(await Api.instance.get('$route/${x['id']}/history') as Map);
        if (!mounted) return;
        await showDialog<void>(
          context: context,
          builder: (c) => AlertDialog(
            title: Text('History · ${x['txn_id']}'),
            content: SizedBox(
              width: double.maxFinite,
              child: ListView(shrinkWrap: true, children: [
                for (final e in (h['items'] as List).map((e) => Map<String, dynamic>.from(e as Map)))
                  ListTile(
                    dense: true,
                    title: Text('${e['action']} · ${e['event_at']} UTC'),
                    subtitle: Text([
                      if ((e['reason'] ?? '').toString().isNotEmpty) 'Reason: ${e['reason']}',
                      if (e['old_values'] is Map && e['new_values'] is Map)
                        ...(e['new_values'] as Map).keys
                            .where((k) => !['updated_at', 'revision'].contains(k) && (e['old_values'] as Map)[k]?.toString() != (e['new_values'] as Map)[k]?.toString())
                            .map((k) => '$k: ${(e['old_values'] as Map)[k]} → ${(e['new_values'] as Map)[k]}'),
                    ].join('\n')),
                  ),
              ]),
            ),
            actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Close'))],
          ),
        );
      } on ApiException catch (e) {
        showSnack(context, e.message, error: true);
      }
    }
  }

  void _changed() {
    reload();
    widget.onChanged?.call();
  }

  Future<void> _filters() async {
    final s = TextEditingController(text: search);
    String? f = from, t = to;
    var rev = showReversed;
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => Padding(
          padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(c).viewInsets.bottom),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('Filter', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            TextField(controller: s, decoration: const InputDecoration(labelText: 'Search ID, description, reference, amount', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: PickerField(label: 'From', icon: Icons.calendar_month, text: dmy(f), onTap: () async {
                final d = await pickDate(c, f);
                set(() => f = d);
              })),
              const SizedBox(width: 8),
              Expanded(child: PickerField(label: 'To', icon: Icons.calendar_month, text: dmy(t), onTap: () async {
                final d = await pickDate(c, t);
                set(() => t = d);
              })),
            ]),
            SwitchListTile(contentPadding: EdgeInsets.zero, value: rev, onChanged: (b) => set(() => rev = b), title: const Text('Show reversed entries')),
            Row(children: [
              TextButton(onPressed: () => Navigator.pop(c, null), child: const Text('Cancel')),
              const Spacer(),
              TextButton(onPressed: () {
                s.clear();
                set(() {
                  f = null;
                  t = null;
                  rev = false;
                });
              }, child: const Text('Clear')),
              FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Apply')),
            ]),
          ]),
        ),
      ),
    );
    if (ok == true) {
      search = s.text.trim();
      from = f;
      to = t;
      showReversed = rev;
      reload();
    }
  }

  @override
  Widget build(BuildContext context) {
    final filtered = search.isNotEmpty || from != null || to != null || showReversed;
    final list = RefreshIndicator(
      onRefresh: reload,
      child: ListView.builder(
        controller: _scroll,
        physics: const AlwaysScrollableScrollPhysics(),
        itemCount: items.length + 2,
        itemBuilder: (c, i) {
          if (i == 0) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 4, 0),
              child: Row(children: [
                Expanded(child: Text('$total record(s) · total ${inr(sum)}', style: const TextStyle(color: Colors.black54, fontSize: 12.5))),
                TextButton.icon(onPressed: _filters, icon: Icon(filtered ? Icons.filter_alt : Icons.filter_alt_outlined), label: Text(filtered ? 'Filtered' : 'Filter')),
              ]),
            );
          }
          if (i == items.length + 1) {
            if (loading) return const Padding(padding: EdgeInsets.all(20), child: Center(child: CircularProgressIndicator()));
            if (error != null) return ErrorView(error!, onRetry: reload);
            if (items.isEmpty) return const Padding(padding: EdgeInsets.all(32), child: Center(child: Text('No records yet.')));
            return const SizedBox(height: 80);
          }
          final x = items[i - 1];
          final reversed = x['status'] == 'reversed';
          return ListTile(
            onTap: () => _actions(x),
            title: Text(_title(x), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(decoration: reversed ? TextDecoration.lineThrough : null)),
            subtitle: Text(_subtitle(x), maxLines: 2, overflow: TextOverflow.ellipsis),
            trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
              MoneyText(_amount(x), style: TextStyle(fontWeight: FontWeight.w700, decoration: reversed ? TextDecoration.lineThrough : null, color: reversed ? Colors.black38 : null)),
              if (reversed) const StatusChip('Reversed', color: bad),
            ]),
          );
        },
      ),
    );
    if (widget.embedded) return list;
    return Scaffold(
      body: list,
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'fab_${widget.type}_${widget.paymentType ?? ''}',
        onPressed: () async {
          if (await openEntry(context, widget.type, preset: {
            if (widget.employeeId != null) 'employee_id': widget.employeeId,
            if (widget.paymentType != null) 'payment_type': widget.paymentType,
          })) _changed();
        },
        icon: const Icon(Icons.add),
        label: Text('New ${txnTitles[widget.type]!.toLowerCase()}'),
      ),
    );
  }
}

extension _IfEmpty on String {
  String ifEmpty(String other) => isEmpty ? other : this;
}

/// Convenience accessor so other screens can refresh shared reference data.
Future<void> refreshMeta() => AppData.instance.load();
