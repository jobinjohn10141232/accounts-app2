import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/data.dart';
import '../core/format.dart';
import '../widgets/common.dart';
import 'entry_form.dart';
import 'txn_list.dart';

/// Expenses tab: cash paid, cash received, accounts & balances.
class ExpensesScreen extends StatelessWidget {
  const ExpensesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const DefaultTabController(
      length: 3,
      child: Column(children: [
        Material(color: Colors.white, child: TabBar(tabs: [Tab(text: 'Cash paid'), Tab(text: 'Cash received'), Tab(text: 'Accounts')])),
        Expanded(child: TabBarView(children: [TxnList(type: 'expense'), TxnList(type: 'receipt'), AccountsTab()])),
      ]),
    );
  }
}

class AccountsTab extends StatefulWidget {
  const AccountsTab({super.key});
  @override
  State<AccountsTab> createState() => _AccountsTabState();
}

class _AccountsTabState extends State<AccountsTab> {
  String asOf = todayYmd();
  Map<String, dynamic>? b;
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = Map<String, dynamic>.from(await Api.instance.get('accounts/balances', {'as_of': asOf}) as Map);
      setState(() {
        b = r;
        error = null;
      });
    } on ApiException catch (e) {
      setState(() => error = e.message);
    }
  }

  @override
  Widget build(BuildContext context) {
    final data = b;
    return RefreshIndicator(
      onRefresh: load,
      child: ListView(padding: const EdgeInsets.fromLTRB(12, 12, 12, 40), children: [
        PickerField(label: 'Balances as of', icon: Icons.calendar_month, text: dmy(asOf), onTap: () async {
          final d = await pickDate(context, asOf);
          if (d != null) {
            setState(() => asOf = d);
            load();
          }
        }),
        const SizedBox(height: 10),
        if (error != null) ErrorView(error!, onRetry: load),
        if (data != null) ...[
          StatGrid(children: [
            for (final e in Map<String, dynamic>.from(data['by_type'] as Map).entries)
              StatCard(title: '${e.key.toUpperCase()} balance', value: inr(e.value), valueColor: isNegative(e.value) ? bad : null),
            StatCard(title: 'Total across accounts', value: inr(data['total']), color: const Color(0xFF7C3AED)),
          ]),
          const SectionTitle('Accounts'),
          Card(
            margin: EdgeInsets.zero,
            child: Column(children: [
              for (final a in (data['accounts'] as List).map((x) => Map<String, dynamic>.from(x as Map)))
                ListTile(
                  title: Text(a['name'].toString()),
                  subtitle: Text('Opening ${inr(a['opening'])}${a['opening_date'] != null ? ' on ${dmy(a['opening_date'])}' : ''} · in ${inr(a['inflow'])} · out ${inr(a['outflow'])}'),
                  trailing: MoneyText(a['balance'], style: const TextStyle(fontWeight: FontWeight.w700)),
                ),
            ]),
          ),
        ],
        const SectionTitle('Actions'),
        Wrap(spacing: 8, runSpacing: 8, children: [
          FilledButton.tonalIcon(onPressed: () async {
            if (await openEntry(context, 'transfer')) load();
          }, icon: const Icon(Icons.swap_horiz), label: const Text('Transfer between accounts')),
          FilledButton.tonalIcon(onPressed: () async {
            if (await openEntry(context, 'adjustment')) load();
          }, icon: const Icon(Icons.balance), label: const Text('Reconcile balance')),
          OutlinedButton(onPressed: () => _open(context, 'Transfers', const TxnList(type: 'transfer')), child: const Text('View transfers')),
          OutlinedButton(onPressed: () => _open(context, 'Adjustments', const TxnList(type: 'adjustment')), child: const Text('View adjustments')),
          OutlinedButton(onPressed: () => _open(context, 'Expense categories', const CategoriesScreen()), child: const Text('Categories')),
        ]),
        const SizedBox(height: 10),
        const Text('Transfers between your own accounts are never counted as income or expense. Opening balances and accounts are configured on the website (Accounts & Cash Balances).', style: TextStyle(color: Colors.black54, fontSize: 12)),
      ]),
    );
  }

  void _open(BuildContext context, String title, Widget w) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: Text(title)), body: w))).then((_) => load());
  }
}

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});
  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  List<Map<String, dynamic>> items = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = await Api.instance.get('categories');
      setState(() => items = (r as List).map((x) => Map<String, dynamic>.from(x as Map)).toList());
    } on ApiException catch (e) {
      showSnack(context, e.message, error: true);
    }
  }

  Future<void> _edit([Map<String, dynamic>? cat]) async {
    final name = TextEditingController(text: cat?['name']?.toString() ?? '');
    final desc = TextEditingController(text: cat?['description']?.toString() ?? '');
    var type = cat?['category_type']?.toString() ?? 'expense';
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => AlertDialog(
          title: Text(cat == null ? 'New category' : 'Edit category'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Name')),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: type,
              items: const [DropdownMenuItem(value: 'expense', child: Text('Expense (cash paid)')), DropdownMenuItem(value: 'income', child: Text('Income / receipt'))],
              onChanged: (v) => set(() => type = v ?? 'expense'),
            ),
            TextField(controller: desc, decoration: const InputDecoration(labelText: 'Description')),
          ]),
          actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Save'))],
        ),
      ),
    );
    if (ok != true) return;
    try {
      final body = {'name': name.text.trim(), 'category_type': type, 'description': desc.text.trim()};
      if (cat == null) {
        await Api.instance.post('categories', body);
      } else {
        await Api.instance.put('categories/${cat['id']}', body);
      }
      await AppData.instance.load();
      load();
    } on ApiException catch (e) {
      showSnack(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(children: [
        for (final c in items)
          ListTile(
            title: Text(c['name'].toString()),
            subtitle: Text('${c['category_type'] == 'income' ? 'Income / receipt' : 'Expense'} · used ${c['usage_count']} time(s)${c['status'] != 'active' ? ' · inactive' : ''}'),
            trailing: PopupMenuButton<String>(
              onSelected: (a) async {
                try {
                  if (a == 'edit') {
                    await _edit(c);
                    return;
                  }
                  if (a == 'toggle') await Api.instance.put('categories/${c['id']}', {'status': c['status'] == 'active' ? 'inactive' : 'active'});
                  if (a == 'delete') await Api.instance.delete('categories/${c['id']}');
                  await AppData.instance.load();
                  load();
                } on ApiException catch (e) {
                  showSnack(context, e.message, error: true);
                }
              },
              itemBuilder: (_) => [
                const PopupMenuItem(value: 'edit', child: Text('Edit')),
                PopupMenuItem(value: 'toggle', child: Text(c['status'] == 'active' ? 'Deactivate' : 'Activate')),
                if ((c['usage_count'] ?? 0) == 0) const PopupMenuItem(value: 'delete', child: Text('Delete')),
              ],
            ),
          ),
      ]),
      floatingActionButton: FloatingActionButton(heroTag: 'fab_cat', onPressed: () => _edit(), child: const Icon(Icons.add)),
    );
  }
}
