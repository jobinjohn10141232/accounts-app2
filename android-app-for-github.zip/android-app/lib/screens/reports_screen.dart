import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/api.dart';
import '../core/data.dart';
import '../core/format.dart';
import '../widgets/common.dart';
import '../widgets/report_view.dart';
import 'dashboard_screen.dart' show periods;

const _empReports = ['employee_ledger', 'employee_summary', 'date_register', 'transactions', 'outstanding', 'work_records', 'payments', 'advances'];

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});
  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  String report = 'employee_summary';
  String period = 'this_month';
  String? from;
  String? to;
  int? employeeId;
  Map<String, dynamic>? table;
  String? error;
  bool loading = false;

  Map<String, dynamic> get params => {
        'period': period,
        if (period == 'custom') 'from': from,
        if (period == 'custom') 'to': to,
        if (employeeId != null && _empReports.contains(report)) 'employee_id': employeeId,
      };

  Future<void> run() async {
    if (report == 'employee_ledger' && employeeId == null) {
      setState(() => error = 'Select an employee for the individual ledger.');
      return;
    }
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final r = Map<String, dynamic>.from(await Api.instance.get('reports/$report', params) as Map);
      setState(() => table = r);
    } on ApiException catch (e) {
      setState(() => error = e.message);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  String get _scope {
    const m = {
      'employee_ledger': 'selected_employee',
      'employee_summary': 'all_employees',
      'date_register': 'all_employees',
      'personal_expense': 'personal_expense',
      'category_expenses': 'personal_expense',
      'daily_cash': 'personal_expense',
      'payments': 'employee_payments',
      'outstanding': 'employee_outstanding',
    };
    return m[report] ?? 'complete';
  }

  @override
  Widget build(BuildContext context) {
    final reports = AppData.instance.reports;
    final emp = AppData.instance.employee(employeeId);
    return ListView(padding: const EdgeInsets.fromLTRB(12, 12, 12, 40), children: [
      DropdownButtonFormField<String>(
        value: reports.containsKey(report) ? report : null,
        isExpanded: true,
        decoration: const InputDecoration(labelText: 'Report', border: OutlineInputBorder()),
        items: reports.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value, overflow: TextOverflow.ellipsis))).toList(),
        onChanged: (v) => setState(() {
          report = v ?? report;
          table = null;
        }),
      ),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(
        value: period,
        decoration: const InputDecoration(labelText: 'Period', border: OutlineInputBorder()),
        items: periods.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(),
        onChanged: (v) async {
          if (v == 'custom') {
            final r = await showDateRangePicker(context: context, firstDate: DateTime(2000), lastDate: DateTime(2100));
            if (r == null) return;
            from = ymd(r.start);
            to = ymd(r.end);
          }
          setState(() => period = v ?? period);
        },
      ),
      if (period == 'custom' && from != null) Padding(padding: const EdgeInsets.only(top: 4), child: Text('${dmy(from)} to ${dmy(to)}', style: const TextStyle(color: Colors.black54))),
      if (_empReports.contains(report)) ...[
        const SizedBox(height: 10),
        PickerField(
          label: report == 'employee_ledger' ? 'Employee' : 'Employee (optional)',
          required: report == 'employee_ledger',
          text: emp == null ? (report == 'employee_ledger' ? '' : 'All employees') : '${emp['name']} · ${emp['employee_code']}',
          onTap: () async {
            final items = <Map<String, dynamic>>[
              if (report != 'employee_ledger') <String, dynamic>{'id': null, 'label': 'All employees'},
              ...AppData.instance.employees(includeInactive: true).map((x) => {'id': x['id'], 'label': x['name'], 'sub': x['employee_code']}),
            ];
            final p = await pickItem(context, 'employees', items);
            if (p != null) setState(() => employeeId = p['id'] == null ? null : int.tryParse(p['id'].toString()));
          },
        ),
      ],
      const SizedBox(height: 12),
      Wrap(spacing: 8, runSpacing: 8, children: [
        FilledButton.icon(onPressed: loading ? null : run, icon: const Icon(Icons.visibility), label: const Text('Preview')),
        FilledButton.tonalIcon(onPressed: () => exportAndShare(context, {'scope': _scope, ...params}), icon: const Icon(Icons.file_download), label: const Text('Excel & share')),
        FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: good),
          onPressed: () => showSendDialog(context, scope: _scope, employeeId: employeeId, period: period, from: from, to: to),
          icon: const Icon(Icons.send),
          label: const Text('GENERATE & SEND'),
        ),
        OutlinedButton.icon(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const DeliveryHistoryScreen())), icon: const Icon(Icons.history), label: const Text('Delivery history')),
      ]),
      const SizedBox(height: 14),
      if (loading) const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator())),
      if (error != null) Padding(padding: const EdgeInsets.all(8), child: Text(error!, style: const TextStyle(color: bad))),
      if (table != null && !loading) ...[
        Text(table!['title'].toString(), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
        Text('${dmy(table!['from'])} to ${dmy(table!['to'])} · ${(table!['rows'] as List).length} row(s)', style: const TextStyle(color: Colors.black54)),
        const SizedBox(height: 10),
        ReportView(table!),
      ],
    ]);
  }
}

/// Generates the Excel file on the server, downloads it and opens the Android share sheet
/// (WhatsApp, Gmail, Drive…). The user picks the recipient – nothing is claimed as "sent".
Future<void> exportAndShare(BuildContext context, Map<String, dynamic> params) async {
  showSnack(context, 'Generating Excel report…');
  try {
    final r = Map<String, dynamic>.from(await Api.instance.post('reports/export', params) as Map);
    final d = Map<String, dynamic>.from(r['delivery'] as Map);
    final f = await Api.instance.download(d['download_url'].toString(), d['file_name'].toString());
    final res = await Share.shareXFiles(
      [XFile(f.path, mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', name: d['file_name'].toString())],
      text: '${d['scope_label']} report · ${dmy(d['date_from'])} to ${dmy(d['date_to'])}',
    );
    if (res.status != ShareResultStatus.dismissed) {
      await Api.instance.post('deliveries/${d['id']}/manual-share', {'status': 'initiated'});
    }
  } on ApiException catch (e) {
    showSnack(context, e.message, error: true);
  }
}

Future<void> showSendDialog(BuildContext context, {String scope = 'complete', int? employeeId, String period = 'this_month', String? from, String? to}) {
  return Navigator.of(context).push(MaterialPageRoute(
    builder: (_) => SendReportScreen(scope: scope, employeeId: employeeId, period: period, from: from, to: to),
  ));
}

class SendReportScreen extends StatefulWidget {
  const SendReportScreen({super.key, required this.scope, this.employeeId, required this.period, this.from, this.to});
  final String scope;
  final int? employeeId;
  final String period;
  final String? from;
  final String? to;

  @override
  State<SendReportScreen> createState() => _SendReportScreenState();
}

class _SendReportScreenState extends State<SendReportScreen> {
  late String scope = widget.scope;
  late String period = widget.period;
  late String? from = widget.from;
  late String? to = widget.to;
  late int? employeeId = widget.employeeId;
  final Set<int> categoryIds = {};
  final email = TextEditingController(text: AppData.instance.settings['default_email']?.toString() ?? '');
  final wa = TextEditingController(text: AppData.instance.settings['default_whatsapp']?.toString() ?? '');
  late bool sendEmail = email.text.isNotEmpty;
  late bool sendWa = wa.text.isNotEmpty;
  bool busy = false;
  Map<String, dynamic>? result;
  String? error;

  Future<void> _send() async {
    if (scope == 'selected_employee' && employeeId == null) {
      setState(() => error = 'Select an employee.');
      return;
    }
    if (scope == 'selected_categories' && categoryIds.isEmpty) {
      setState(() => error = 'Select at least one category.');
      return;
    }
    setState(() {
      busy = true;
      error = null;
      result = null;
    });
    try {
      final r = await Api.instance.post('reports/send', {
        'scope': scope,
        'period': period,
        if (period == 'custom') 'from': from,
        if (period == 'custom') 'to': to,
        if (scope == 'selected_employee') 'employee_id': employeeId,
        if (scope == 'selected_categories') 'category_ids': categoryIds.join(','),
        'email': email.text.trim(),
        'whatsapp': wa.text.trim(),
        'send_email': sendEmail,
        'send_whatsapp': sendWa,
      });
      setState(() => result = Map<String, dynamic>.from(r as Map));
    } on ApiException catch (e) {
      setState(() => error = e.isNetwork ? 'Reports can only be generated while online.' : e.message);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _shareManually(Map<String, dynamic> d) async {
    try {
      final f = await Api.instance.download(d['download_url'].toString(), d['file_name'].toString());
      final res = await Share.shareXFiles(
        [XFile(f.path, mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', name: d['file_name'].toString())],
        text: (result?['summary_text'] ?? '').toString(),
      );
      if (res.status != ShareResultStatus.dismissed) {
        await Api.instance.post('deliveries/${d['id']}/manual-share', {'status': 'initiated'});
        showSnack(context, 'Share sheet completed. Delivery cannot be verified automatically.');
      }
    } on ApiException catch (e) {
      showSnack(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scopes = AppData.instance.scopes;
    final emp = AppData.instance.employee(employeeId);
    final apiReady = AppData.instance.settings['whatsapp_api_ready'] == true;
    final d = result == null ? null : Map<String, dynamic>.from(result!['delivery'] as Map);
    return Scaffold(
      appBar: AppBar(title: const Text('Generate & send report')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        DropdownButtonFormField<String>(
          value: scopes.containsKey(scope) ? scope : null,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Report type', border: OutlineInputBorder()),
          items: scopes.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(),
          onChanged: (v) => setState(() => scope = v ?? scope),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: period,
          decoration: const InputDecoration(labelText: 'Date range', border: OutlineInputBorder()),
          items: periods.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(),
          onChanged: (v) async {
            if (v == 'custom') {
              final r = await showDateRangePicker(context: context, firstDate: DateTime(2000), lastDate: DateTime(2100));
              if (r == null) return;
              from = ymd(r.start);
              to = ymd(r.end);
            }
            setState(() => period = v ?? period);
          },
        ),
        if (period == 'custom' && from != null) Text('${dmy(from)} to ${dmy(to)}', style: const TextStyle(color: Colors.black54)),
        if (scope == 'selected_employee') ...[
          const SizedBox(height: 12),
          PickerField(
            label: 'Employee',
            required: true,
            text: emp == null ? '' : '${emp['name']} · ${emp['employee_code']}',
            onTap: () async {
              final p = await pickItem(context, 'employees', AppData.instance.employees(includeInactive: true).map((x) => {'id': x['id'], 'label': x['name'], 'sub': x['employee_code']}).toList());
              if (p != null) setState(() => employeeId = int.tryParse(p['id'].toString()));
            },
          ),
        ],
        if (scope == 'selected_categories') ...[
          const SizedBox(height: 12),
          const Text('Categories', style: TextStyle(fontWeight: FontWeight.w600)),
          Wrap(spacing: 6, children: [
            for (final c in AppData.instance.categories('expense', includeInactive: true))
              FilterChip(
                label: Text(c['name'].toString()),
                selected: categoryIds.contains(int.parse(c['id'].toString())),
                onSelected: (s) => setState(() => s ? categoryIds.add(int.parse(c['id'].toString())) : categoryIds.remove(int.parse(c['id'].toString()))),
              ),
          ]),
        ],
        const SizedBox(height: 12),
        TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email address', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: wa, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'WhatsApp recipient', border: OutlineInputBorder())),
        const SizedBox(height: 4),
        const ListTile(dense: true, contentPadding: EdgeInsets.zero, title: Text('Format'), trailing: Text('Excel workbook (.xlsx)')),
        CheckboxListTile(contentPadding: EdgeInsets.zero, value: sendEmail, onChanged: (b) => setState(() => sendEmail = b ?? false), title: const Text('Send email')),
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          value: sendWa,
          onChanged: (b) => setState(() => sendWa = b ?? false),
          title: const Text('Send WhatsApp'),
          subtitle: Text(apiReady ? 'Via WhatsApp Business API' : 'API not configured – you will share the file manually'),
        ),
        const SizedBox(height: 8),
        FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: good, padding: const EdgeInsets.symmetric(vertical: 14)),
          onPressed: busy ? null : _send,
          icon: busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.send),
          label: const Text('GENERATE & SEND REPORT'),
        ),
        if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: const TextStyle(color: bad))),
        if (d != null) ...[
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Delivery status · ${d['report_id']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                _statusRow('Report generated', 'sent', d['file_name'].toString()),
                _statusRow('Email', d['email_status'].toString(), '${d['email_status_label']}${(d['email_to'] ?? '').toString().isNotEmpty ? ' · ${d['email_to']}' : ''}${d['email_error'] != null ? '\n${d['email_error']}' : ''}'),
                _statusRow('WhatsApp', d['wa_status'].toString(), '${d['wa_status_label']}${(d['wa_to'] ?? '').toString().isNotEmpty ? ' · ${d['wa_to']}' : ''}${d['wa_error'] != null && d['wa_status'] == 'failed' ? '\n${d['wa_error']}' : ''}'),
                if (d['wa_status'] == 'manual_required' || d['wa_status'] == 'failed') ...[
                  const Divider(),
                  const Text('Manual WhatsApp sharing', style: TextStyle(fontWeight: FontWeight.w700)),
                  const Text('Tap below, choose WhatsApp in the share sheet, pick the recipient and send. The app cannot confirm delivery.', style: TextStyle(fontSize: 12.5, color: Colors.black54)),
                  const SizedBox(height: 8),
                  Wrap(spacing: 8, children: [
                    FilledButton.icon(onPressed: () => _shareManually(d), icon: const Icon(Icons.share), label: const Text('Share Excel file')),
                    if (result?['manual_share'] is Map)
                      OutlinedButton(
                        onPressed: () => launchUrl(Uri.parse((result!['manual_share'] as Map)['whatsapp_url'].toString()), mode: LaunchMode.externalApplication),
                        child: const Text('Open chat with summary'),
                      ),
                  ]),
                ],
              ]),
            ),
          ),
        ],
      ]),
    );
  }

  Widget _statusRow(String k, String status, String text) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(width: 120, child: Text(k, style: const TextStyle(color: Colors.black54))),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [StatusChip(status, color: statusColor(status)), Text(text, style: const TextStyle(fontSize: 12.5))])),
        ]),
      );
}

class DeliveryHistoryScreen extends StatefulWidget {
  const DeliveryHistoryScreen({super.key});
  @override
  State<DeliveryHistoryScreen> createState() => _DeliveryHistoryScreenState();
}

class _DeliveryHistoryScreenState extends State<DeliveryHistoryScreen> {
  List<Map<String, dynamic>> items = [];
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = Map<String, dynamic>.from(await Api.instance.get('deliveries', {'per_page': 100}) as Map);
      setState(() => items = (r['items'] as List).map((x) => Map<String, dynamic>.from(x as Map)).toList());
    } on ApiException catch (e) {
      setState(() => error = e.message);
    }
  }

  Future<void> _retry(Map<String, dynamic> d, String ch) async {
    try {
      await Api.instance.post('deliveries/${d['id']}/retry', {'channel': ch});
      showSnack(context, 'Retry done');
      load();
    } on ApiException catch (e) {
      showSnack(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Report delivery history')),
      body: error != null
          ? ErrorView(error!, onRetry: load)
          : RefreshIndicator(
              onRefresh: load,
              child: ListView.separated(
                itemCount: items.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (c, i) {
                  final d = items[i];
                  return ListTile(
                    title: Text('${d['scope_label']} · ${dmy(d['date_from'])}–${dmy(d['date_to'])}'),
                    subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${d['report_id']} · ${d['generated_at']} UTC', style: const TextStyle(fontSize: 11.5)),
                      const SizedBox(height: 4),
                      Wrap(spacing: 6, runSpacing: 4, children: [
                        StatusChip('Email: ${d['email_status_label']}', color: statusColor(d['email_status'].toString())),
                        StatusChip('WhatsApp: ${d['wa_status_label']}', color: statusColor(d['wa_status'].toString())),
                        if (d['manual_share_status'] != 'none') StatusChip(d['manual_share_label'].toString(), color: warn),
                      ]),
                    ]),
                    isThreeLine: true,
                    trailing: PopupMenuButton<String>(
                      onSelected: (a) async {
                        if (a == 'email' || a == 'whatsapp') {
                          await _retry(d, a);
                        } else if (a == 'share' && d['download_url'] != null) {
                          try {
                            final f = await Api.instance.download(d['download_url'].toString(), d['file_name'].toString());
                            await Share.shareXFiles([XFile(f.path, name: d['file_name'].toString())]);
                          } on ApiException catch (e) {
                            showSnack(context, e.message, error: true);
                          }
                        }
                      },
                      itemBuilder: (_) => [
                        if (d['email_status'] != 'not_requested') const PopupMenuItem(value: 'email', child: Text('Retry email')),
                        if (d['wa_status'] != 'not_requested') const PopupMenuItem(value: 'whatsapp', child: Text('Retry WhatsApp')),
                        if (d['file_available'] == true) const PopupMenuItem(value: 'share', child: Text('Download & share')),
                      ],
                    ),
                  );
                },
              ),
            ),
    );
  }
}
