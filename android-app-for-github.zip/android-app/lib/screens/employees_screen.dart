import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/data.dart';
import '../core/format.dart';
import '../widgets/common.dart';
import 'entry_form.dart';
import 'reports_screen.dart';
import 'txn_list.dart';

class EmployeesScreen extends StatefulWidget {
  const EmployeesScreen({super.key});
  @override
  State<EmployeesScreen> createState() => _EmployeesScreenState();
}

class _EmployeesScreenState extends State<EmployeesScreen> {
  List<Map<String, dynamic>> items = [];
  String status = 'current';
  String search = '';
  bool loading = false;
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final r = Map<String, dynamic>.from(await Api.instance.get('employees', {'status': status, 'search': search, 'with_balances': 1, 'per_page': 300}) as Map);
      setState(() => items = (r['items'] as List).map((e) => Map<String, dynamic>.from(e as Map)).toList());
    } on ApiException catch (e) {
      if (e.isNetwork) {
        // Offline: show cached reference list (balances unavailable).
        setState(() {
          items = AppData.instance.employees(includeInactive: true).where((x) => search.isEmpty || '${x['name']} ${x['employee_code']} ${x['mobile']}'.toLowerCase().contains(search.toLowerCase())).toList();
          error = 'Offline – balances unavailable.';
        });
      } else {
        setState(() => error = e.message);
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
          child: TextField(
            decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Name, employee ID or mobile', border: OutlineInputBorder(), isDense: true),
            onChanged: (s) {
              search = s;
              load();
            },
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(children: [
            for (final s in const {'current': 'Active & inactive', 'active': 'Active', 'inactive': 'Inactive', 'archived': 'Archived', 'all': 'All'}.entries)
              Padding(
                padding: const EdgeInsets.only(right: 6),
                child: ChoiceChip(label: Text(s.value), selected: status == s.key, onSelected: (_) {
                  setState(() => status = s.key);
                  load();
                }),
              ),
          ]),
        ),
        if (error != null) Padding(padding: const EdgeInsets.all(8), child: Text(error!, style: const TextStyle(color: warn))),
        Expanded(
          child: RefreshIndicator(
            onRefresh: load,
            child: loading && items.isEmpty
                ? const Center(child: CircularProgressIndicator())
                : ListView.separated(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.only(bottom: 90),
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (c, i) {
                      final e = items[i];
                      final b = e['balances'] is Map ? Map<String, dynamic>.from(e['balances'] as Map) : null;
                      return ListTile(
                        leading: CircleAvatar(backgroundColor: e['status'] == 'active' ? brand : Colors.grey, child: Text(e['name'].toString().substring(0, 1).toUpperCase(), style: const TextStyle(color: Colors.white))),
                        title: Text(e['name'].toString()),
                        subtitle: Text('${e['employee_code']} · ${inr(e['daily_wage'])}/day${e['status'] != 'active' ? ' · ${e['status']}' : ''}'),
                        trailing: b == null
                            ? null
                            : Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
                                MoneyText(b['outstanding_wages'], style: const TextStyle(fontWeight: FontWeight.w700)),
                                if (num0(b['outstanding_advance']) != 0) Text('adv ${inr(b['outstanding_advance'])}', style: const TextStyle(fontSize: 11, color: warn)),
                              ]),
                        onTap: () async {
                          await Navigator.of(context).push(MaterialPageRoute(builder: (_) => EmployeeProfile(id: int.parse(e['id'].toString()))));
                          load();
                        },
                      );
                    },
                  ),
          ),
        ),
      ]),
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'fab_emp',
        onPressed: () async {
          if (await openEmployeeForm(context) != null) load();
        },
        icon: const Icon(Icons.person_add),
        label: const Text('Add employee'),
      ),
    );
  }
}

class EmployeeProfile extends StatefulWidget {
  const EmployeeProfile({super.key, required this.id});
  final int id;
  @override
  State<EmployeeProfile> createState() => _EmployeeProfileState();
}

class _EmployeeProfileState extends State<EmployeeProfile> {
  Map<String, dynamic>? p;
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = Map<String, dynamic>.from(await Api.instance.get('employees/${widget.id}/profile') as Map);
      setState(() {
        p = r;
        error = null;
      });
    } on ApiException catch (e) {
      setState(() => error = e.message);
    }
  }

  Future<void> _status(String s) async {
    final reason = await askText(context, 'Change status to $s', 'Reason (optional)', required: false);
    if (reason == null) return;
    try {
      await Api.instance.post('employees/${widget.id}/status', {'status': s, 'reason': reason});
      await AppData.instance.load();
      showSnack(context, 'Status changed to $s');
      load();
    } on ApiException catch (e) {
      showSnack(context, e.message, error: true);
    }
  }

  Future<void> _delete() async {
    if (!await confirmDialog(context, 'Delete employee?', 'Only employees without any financial records can be deleted. Otherwise archive them.', ok: 'Delete', danger: true)) return;
    try {
      await Api.instance.delete('employees/${widget.id}');
      await AppData.instance.load();
      if (mounted) Navigator.pop(context);
    } on ApiException catch (e) {
      showSnack(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final data = p;
    if (data == null) {
      return Scaffold(appBar: AppBar(title: const Text('Employee')), body: error != null ? ErrorView(error!, onRetry: load) : const Center(child: CircularProgressIndicator()));
    }
    final e = Map<String, dynamic>.from(data['employee'] as Map);
    final pos = Map<String, dynamic>.from(data['position'] as Map);
    final ledger = Map<String, dynamic>.from(data['ledger'] as Map);
    final rows = (ledger['rows'] as List).map((x) => Map<String, dynamic>.from(x as Map)).toList().reversed.toList();
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: Text(e['name'].toString()),
          actions: [
            IconButton(tooltip: 'Edit', icon: const Icon(Icons.edit), onPressed: () async {
              if (await openEmployeeForm(context, employee: e) != null) load();
            }),
            PopupMenuButton<String>(
              onSelected: (s) {
                if (s == 'delete') {
                  _delete();
                } else if (s == 'report') {
                  showSendDialog(context, scope: 'selected_employee', employeeId: widget.id);
                } else {
                  _status(s);
                }
              },
              itemBuilder: (_) => [
                const PopupMenuItem(value: 'report', child: Text('Ledger report (Excel / send)')),
                if (e['status'] != 'active') const PopupMenuItem(value: 'active', child: Text('Reactivate')),
                if (e['status'] == 'active') const PopupMenuItem(value: 'inactive', child: Text('Deactivate')),
                if (e['status'] != 'archived') const PopupMenuItem(value: 'archived', child: Text('Archive')),
                const PopupMenuItem(value: 'delete', child: Text('Delete (only without records)')),
              ],
            ),
          ],
          bottom: const TabBar(isScrollable: true, tabs: [Tab(text: 'Ledger'), Tab(text: 'Work'), Tab(text: 'Payments'), Tab(text: 'Details')]),
        ),
        body: TabBarView(children: [
          RefreshIndicator(
            onRefresh: load,
            child: ListView(padding: const EdgeInsets.all(12), children: [
              Text('${e['employee_code']} · ${e['designation'] ?? ''} · ${e['status']}', style: const TextStyle(color: Colors.black54)),
              const SizedBox(height: 10),
              StatGrid(children: [
                StatCard(title: 'Total working days', value: qty(pos['days'])),
                StatCard(title: 'Total wages earned', value: inr(pos['earned']), color: const Color(0xFF2E6AA3)),
                StatCard(title: 'Payments against wages', value: inr(pos['wage_payments']), color: good),
                StatCard(title: 'Outstanding earned wages', value: inr(pos['outstanding_wages']), color: bad, valueColor: bad),
                StatCard(title: 'Unrecovered advance', value: inr(pos['outstanding_advance']), subtitle: 'issued ${inr(pos['pay_advance'])} · recovered ${inr(pos['advance_recovered'])}', color: warn),
                StatCard(title: 'Net payable to employee', value: inr(pos['net_position']), subtitle: isNegative(pos['net_position']) ? 'employee owes you' : 'you owe the employee', valueColor: isNegative(pos['net_position']) ? bad : null),
              ]),
              const SizedBox(height: 10),
              Wrap(spacing: 6, children: [
                FilledButton.tonalIcon(onPressed: () async {
                  if (await openEntry(context, 'work', preset: {'employee_id': widget.id})) load();
                }, icon: const Icon(Icons.event_available), label: const Text('Work day')),
                FilledButton.tonalIcon(onPressed: () async {
                  if (await openEntry(context, 'payment', preset: {'employee_id': widget.id})) load();
                }, icon: const Icon(Icons.payments), label: const Text('Payment')),
                FilledButton.tonalIcon(onPressed: () async {
                  if (await openEntry(context, 'payment', preset: {'employee_id': widget.id, 'payment_type': 'advance'})) load();
                }, icon: const Icon(Icons.north_east), label: const Text('Advance')),
                FilledButton.tonalIcon(onPressed: () async {
                  if (await openEntry(context, 'recovery', preset: {'employee_id': widget.id})) load();
                }, icon: const Icon(Icons.south_west), label: const Text('Recovery')),
              ]),
              const SectionTitle('Date-wise ledger (newest first)'),
              for (final r in rows) _ledgerTile(r),
              Card(
                color: const Color(0xFFEEF4FB),
                child: ListTile(
                  title: Text('Opening balance (${dmy(ledger['from'])})'),
                  trailing: Text('Wages ${inr((ledger['opening'] as Map)['outstanding_wages'])}\nAdvance ${inr((ledger['opening'] as Map)['outstanding_advance'])}', textAlign: TextAlign.right),
                ),
              ),
              const SectionTitle('Wage rate history'),
              for (final w in (data['wage_history'] as List).map((x) => Map<String, dynamic>.from(x as Map)))
                ListTile(dense: true, title: Text('${inr(w['daily_wage'])} per day'), subtitle: Text('Effective from ${dmy(w['effective_from'])}${(w['note'] ?? '').toString().isNotEmpty ? ' · ${w['note']}' : ''}')),
            ]),
          ),
          TxnList(type: 'work', employeeId: widget.id, onChanged: load),
          TxnList(type: 'payment', employeeId: widget.id, onChanged: load),
          ListView(padding: const EdgeInsets.all(12), children: [
            for (final kv in {
              'Employee ID': e['employee_code'],
              'Mobile': e['mobile'],
              'Address': e['address'],
              'Date of joining': dmy(e['date_of_joining']),
              'Designation': e['designation'],
              'Current daily wage': inr(e['daily_wage']),
              'Payment notes': e['payment_notes'],
              'Emergency contact': e['emergency_contact'],
              'Notes': e['notes'],
              'Status': e['status'],
            }.entries)
              ListTile(dense: true, title: Text(kv.key, style: const TextStyle(color: Colors.black54, fontSize: 12)), subtitle: Text((kv.value ?? '').toString().isEmpty ? '—' : kv.value.toString(), style: const TextStyle(fontSize: 15, color: Colors.black87))),
          ]),
        ]),
      ),
    );
  }

  Widget _ledgerTile(Map<String, dynamic> r) {
    final kind = r['entry_kind'];
    final title = kind == 'work'
        ? 'Work · ${workStatusLabels[r['work_status']] ?? ''} · ${qty(r['day_qty'])} × ${inr(r['wage_rate'])}'
        : kind == 'payment'
            ? (r['payment_type'] == 'advance' ? 'Advance issued' : (paymentTypeLabels[r['payment_type']] ?? 'Payment'))
            : (r['payment_type'].toString().contains('wage_offset') ? 'Advance recovered from wages' : 'Advance repaid in cash');
    final amount = kind == 'work' ? r['earned'] : (num0(r['advance_issued']) != 0 ? r['advance_issued'] : (num0(r['payment']) != 0 ? r['payment'] : r['advance_recovered']));
    return Card(
      margin: const EdgeInsets.only(bottom: 6),
      child: ListTile(
        dense: true,
        leading: Icon(kind == 'work' ? Icons.work_outline : (kind == 'payment' ? Icons.payments_outlined : Icons.swap_horiz), color: kind == 'work' ? brand : (kind == 'payment' ? good : warn)),
        title: Text(title),
        subtitle: Text('${dmy(r['date'])} · ${r['txn_id']}\nBalance: wages ${inr(r['wage_balance'])} · advance ${inr(r['advance_balance'])}'),
        isThreeLine: true,
        trailing: Text(inr(amount), style: const TextStyle(fontWeight: FontWeight.w700)),
      ),
    );
  }
}
