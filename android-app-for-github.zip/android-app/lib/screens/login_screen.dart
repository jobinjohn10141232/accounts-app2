import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/api.dart';
import '../core/session.dart';
import '../widgets/common.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, this.onLoggedIn});
  final VoidCallback? onLoggedIn;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _site = TextEditingController(text: Session.instance.site ?? '');
  final _user = TextEditingController();
  final _pass = TextEditingController();
  bool _busy = false;
  bool _show = false;
  String? _error;

  Future<void> _login() async {
    setState(() {
      _error = null;
    });
    String site;
    try {
      site = Session.normaliseSite(_site.text);
    } on FormatException catch (e) {
      setState(() => _error = e.message);
      return;
    }
    if (_user.text.trim().isEmpty || _pass.text.isEmpty) {
      setState(() => _error = 'Enter your username/email and password.');
      return;
    }
    setState(() => _busy = true);
    try {
      final r = await Api.instance.login(site, _user.text.trim(), _pass.text);
      await Session.instance.saveLogin(
        r['token'].toString(),
        Map<String, dynamic>.from((r['user'] as Map?) ?? const {}),
        int.tryParse(r['idle_timeout_minutes'].toString()) ?? 30,
      );
      _pass.clear();
      widget.onLoggedIn?.call();
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _forgot() async {
    String site;
    try {
      site = Session.normaliseSite(_site.text);
    } on FormatException catch (e) {
      setState(() => _error = e.message);
      return;
    }
    final login = await askText(context, 'Reset password', 'Username or email');
    if (login == null) return;
    try {
      await Session.instance.setSite(site);
      final r = await Api.instance.send('POST', 'auth/password-reset', body: {'login': login}, auth: false);
      if (!mounted) return;
      showSnack(context, (r as Map)['message'].toString());
      final url = r['reset_url']?.toString();
      if (url != null && url.isNotEmpty) {
        await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      }
    } on ApiException catch (e) {
      showSnack(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Container(
                  width: 64,
                  height: 64,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: brand, borderRadius: BorderRadius.circular(16)),
                  child: const Text('₹', style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w700)),
                ),
                const SizedBox(height: 16),
                const Text('Personal Accounts Manager', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                const Text('Private administrator login', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
                const SizedBox(height: 28),
                TextField(
                  controller: _site,
                  keyboardType: TextInputType.url,
                  autocorrect: false,
                  decoration: const InputDecoration(labelText: 'Website address', hintText: 'https://your-site.com', prefixIcon: Icon(Icons.language), border: OutlineInputBorder()),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _user,
                  autocorrect: false,
                  decoration: const InputDecoration(labelText: 'Username or email', prefixIcon: Icon(Icons.person_outline), border: OutlineInputBorder()),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _pass,
                  obscureText: !_show,
                  onSubmitted: (_) => _login(),
                  decoration: InputDecoration(
                    labelText: 'Password',
                    prefixIcon: const Icon(Icons.lock_outline),
                    border: const OutlineInputBorder(),
                    suffixIcon: IconButton(icon: Icon(_show ? Icons.visibility_off : Icons.visibility), onPressed: () => setState(() => _show = !_show)),
                  ),
                ),
                if (_error != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Text(_error!, style: const TextStyle(color: bad)),
                  ),
                const SizedBox(height: 20),
                FilledButton(
                  onPressed: _busy ? null : _login,
                  style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
                  child: _busy ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Text('Log in'),
                ),
                TextButton(onPressed: _forgot, child: const Text('Forgot password?')),
                const SizedBox(height: 8),
                const Text(
                  'Only HTTPS connections are allowed. Your password is sent once to obtain a revocable session token and is never stored on this phone.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: Colors.black45),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
