import 'dart:math' as math;

import 'package:flutter/material.dart';

class ChartSeries {
  const ChartSeries(this.name, this.values, this.color);
  final String name;
  final List<double> values;
  final Color color;
}

String _short(double v) {
  final a = v.abs();
  if (a >= 1e7) return '₹${(v / 1e7).toStringAsFixed(1)}Cr';
  if (a >= 1e5) return '₹${(v / 1e5).toStringAsFixed(1)}L';
  if (a >= 1e3) return '₹${(v / 1e3).toStringAsFixed(1)}k';
  return '₹${v.round()}';
}

/// Dependency-free grouped bar chart.
class GroupedBarChart extends StatelessWidget {
  const GroupedBarChart({super.key, required this.labels, required this.series, this.height = 200});
  final List<String> labels;
  final List<ChartSeries> series;
  final double height;

  @override
  Widget build(BuildContext context) {
    final max = series.expand((s) => s.values).fold<double>(0, (a, b) => math.max(a, b));
    if (max <= 0) return const SizedBox(height: 80, child: Center(child: Text('No data for this period', style: TextStyle(color: Colors.black45))));
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(height: height, width: double.infinity, child: CustomPaint(painter: _BarPainter(labels, series, max))),
      const SizedBox(height: 6),
      Wrap(spacing: 12, runSpacing: 4, children: [
        for (final s in series)
          Row(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 10, height: 10, decoration: BoxDecoration(color: s.color, borderRadius: BorderRadius.circular(2))),
            const SizedBox(width: 4),
            Text(s.name, style: const TextStyle(fontSize: 11.5)),
          ]),
      ]),
    ]);
  }
}

class _BarPainter extends CustomPainter {
  _BarPainter(this.labels, this.series, this.max);
  final List<String> labels;
  final List<ChartSeries> series;
  final double max;

  @override
  void paint(Canvas canvas, Size size) {
    const left = 44.0, bottom = 20.0, top = 6.0;
    final h = size.height - bottom - top;
    final w = size.width - left;
    final grid = Paint()..color = const Color(0xFFE9EDF2);
    final textStyle = const TextStyle(fontSize: 9.5, color: Color(0xFF6B7486));
    for (var g = 0; g <= 4; g++) {
      final y = top + h * (1 - g / 4);
      canvas.drawLine(Offset(left, y), Offset(size.width, y), grid);
      final tp = TextPainter(text: TextSpan(text: _short(max * g / 4), style: textStyle), textDirection: TextDirection.ltr)..layout();
      tp.paint(canvas, Offset(left - tp.width - 4, y - tp.height / 2));
    }
    final n = labels.length;
    if (n == 0) return;
    final groupW = w / n;
    final bw = math.max(2.0, math.min(14.0, (groupW - 4) / series.length));
    final every = (n / 8).ceil();
    for (var i = 0; i < n; i++) {
      final gx = left + i * groupW + (groupW - bw * series.length) / 2;
      for (var j = 0; j < series.length; j++) {
        final v = i < series[j].values.length ? series[j].values[i] : 0.0;
        final bh = h * (v <= 0 ? 0 : v) / max;
        final rect = RRect.fromRectAndRadius(Rect.fromLTWH(gx + j * bw, top + h - bh, bw - 1.5, bh), const Radius.circular(2));
        canvas.drawRRect(rect, Paint()..color = series[j].color);
      }
      if (i % every == 0) {
        final tp = TextPainter(text: TextSpan(text: labels[i], style: textStyle), textDirection: TextDirection.ltr)..layout();
        tp.paint(canvas, Offset(left + i * groupW + groupW / 2 - tp.width / 2, size.height - bottom + 4));
      }
    }
  }

  @override
  bool shouldRepaint(covariant _BarPainter old) => old.labels != labels || old.series != series || old.max != max;
}

/// Horizontal proportion bars (category breakdown / outstanding by employee).
class ProportionBars extends StatelessWidget {
  const ProportionBars({super.key, required this.items, this.color = const Color(0xFF2E6AA3), this.emptyText = 'No data'});
  final List<MapEntry<String, double>> items;
  final Color color;
  final String emptyText;

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return Padding(padding: const EdgeInsets.all(12), child: Text(emptyText, style: const TextStyle(color: Colors.black45)));
    final max = items.map((e) => e.value).fold<double>(0, (a, b) => math.max(a, b));
    final total = items.map((e) => e.value).fold<double>(0, (a, b) => a + b);
    return Column(children: [
      for (final e in items.take(10))
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(children: [
            SizedBox(width: 110, child: Text(e.key, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12))),
            Expanded(
              child: LayoutBuilder(
                builder: (c, k) => Align(
                  alignment: Alignment.centerLeft,
                  child: Container(height: 14, width: max <= 0 ? 0 : k.maxWidth * e.value / max, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(3))),
                ),
              ),
            ),
            SizedBox(width: 92, child: Text('${_short(e.value)} · ${total <= 0 ? 0 : (100 * e.value / total).round()}%', textAlign: TextAlign.right, style: const TextStyle(fontSize: 11.5))),
          ]),
        ),
    ]);
  }
}
