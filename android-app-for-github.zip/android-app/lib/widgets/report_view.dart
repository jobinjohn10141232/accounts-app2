import 'package:flutter/material.dart';

import '../core/format.dart';
import 'common.dart';

/// Renders a server report table (typed columns, rows, totals, summary, opening/closing).
class ReportView extends StatelessWidget {
  const ReportView(this.table, {super.key});
  final Map<String, dynamic> table;

  String _fmt(String type, dynamic v) {
    if (v == null || v.toString().isEmpty) return '';
    switch (type) {
      case 'money':
        return num0(v) == 0 ? '–' : inr(v);
      case 'qty':
        return qty(v);
      case 'date':
        return dmy(v);
      case 'pct':
        return '${num0(v).toStringAsFixed(2)}%';
      default:
        return v.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    final cols = ((table['columns'] as List?) ?? const []).map((c) => Map<String, dynamic>.from(c as Map)).toList();
    final rows = ((table['rows'] as List?) ?? const []).map((r) => Map<String, dynamic>.from(r as Map)).toList();
    final totals = Map<String, dynamic>.from((table['totals'] as Map?) ?? const {});
    final summary = ((table['summary'] as List?) ?? const []).map((s) => Map<String, dynamic>.from(s as Map)).toList();
    final opening = table['opening'] is Map ? Map<String, dynamic>.from(table['opening'] as Map) : null;
    final closing = table['closing'] is Map ? Map<String, dynamic>.from(table['closing'] as Map) : null;
    final numeric = (String t) => t == 'money' || t == 'qty' || t == 'int' || t == 'pct';

    DataRow special(String label, Map<String, dynamic> values, {bool bold = true}) => DataRow(
          color: WidgetStateProperty.all(const Color(0xFFEEF4FB)),
          cells: [
            for (var i = 0; i < cols.length; i++)
              DataCell(Text(
                i == 0 ? label : (values.containsKey(cols[i]['key']) ? (cols[i]['type'] == 'qty' ? qty(values[cols[i]['key']]) : inr(values[cols[i]['key']])) : ''),
                style: TextStyle(fontWeight: bold ? FontWeight.w700 : FontWeight.w500),
              )),
          ],
        );

    final dataRows = <DataRow>[
      if (opening != null) special('Opening balance', opening, bold: false),
      for (final r in rows)
        DataRow(
          color: r['row_kind'] == 'category' ? WidgetStateProperty.all(const Color(0xFFF4F7FB)) : null,
          cells: [
            for (final c in cols)
              DataCell(Align(
                alignment: numeric(c['type'].toString()) ? Alignment.centerRight : Alignment.centerLeft,
                child: Text(
                  c['type'] == 'mixed' ? _fmt((r['value_type'] ?? 'text').toString(), r['value']) : _fmt(c['type'].toString(), r[c['key']]),
                  style: TextStyle(
                    color: c['type'] == 'money' && isNegative(r[c['key']]) ? bad : null,
                    fontWeight: r['row_kind'] == 'category' ? FontWeight.w700 : null,
                  ),
                ),
              )),
          ],
        ),
      if (totals.isNotEmpty) special('TOTAL', totals),
      if (closing != null) special('Closing balance', closing),
    ];

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      if (summary.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: StatGrid(children: [
            for (final s in summary)
              StatCard(
                title: s['label'].toString(),
                value: s['type'] == 'money' ? inr(s['value']) : (s['type'] == 'qty' ? qty(s['value']) : s['value'].toString()),
                valueColor: s['type'] == 'money' && isNegative(s['value']) ? bad : null,
              ),
          ]),
        ),
      if (rows.isEmpty)
        const Padding(padding: EdgeInsets.all(16), child: Text('No records for the selected period.'))
      else
        Card(
          margin: EdgeInsets.zero,
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              headingRowColor: WidgetStateProperty.all(const Color(0xFFF2F5F9)),
              headingTextStyle: const TextStyle(fontWeight: FontWeight.w700, color: Colors.black87, fontSize: 12.5),
              dataTextStyle: const TextStyle(fontSize: 12.5, color: Colors.black87),
              columnSpacing: 18,
              horizontalMargin: 12,
              dataRowMinHeight: 36,
              dataRowMaxHeight: 52,
              columns: [for (final c in cols) DataColumn(label: Text(c['label'].toString()), numeric: numeric(c['type'].toString()))],
              rows: dataRows,
            ),
          ),
        ),
      for (final s in ((table['sub_tables'] as List?) ?? const []))
        Padding(
          padding: const EdgeInsets.only(top: 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text((s as Map)['title'].toString(), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
            const SizedBox(height: 8),
            ReportView(Map<String, dynamic>.from(s)),
          ]),
        ),
    ]);
  }
}
