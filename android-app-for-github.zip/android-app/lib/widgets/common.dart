import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../core/api.dart';
import '../core/format.dart';
import '../core/outbox.dart';

const brand = Color(0xFF1F4E79);
const good = Color(0xFF1B7F4B);
const bad = Color(0xFFB42318);
const warn = Color(0xFFD97706);

final _uuid = Uuid();
String newUuid() => _uuid.v4();

void showSnack(BuildContext context, String msg, {bool error = false}) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: error ? bad : null,
      duration: Duration(seconds: error ? 6 : 3),
    ));
}

Future<bool> confirmDialog(BuildContext context, String title, String message, {String ok = 'OK', bool danger = false}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
        FilledButton(
          style: danger ? FilledButton.styleFrom(backgroundColor: bad) : null,
          onPressed: () => Navigator.pop(c, true),
          child: Text(ok),
        ),
      ],
    ),
  );
  return r ?? false;
}

Future<String?> askText(BuildContext context, String title, String label, {bool required = true, String? message}) async {
  final ctl = TextEditingController();
  String? err;
  return showDialog<String>(
    context: context,
    builder: (c) => StatefulBuilder(
      builder: (c, set) => AlertDialog(
        title: Text(title),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (message != null) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(message)),
          TextField(controller: ctl, autofocus: true, maxLines: 3, minLines: 1, decoration: InputDecoration(labelText: label, errorText: err, border: const OutlineInputBorder())),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              if (required && ctl.text.trim().isEmpty) {
                set(() => err = 'Required');
                return;
              }
              Navigator.pop(c, ctl.text.trim());
            },
            child: const Text('Confirm'),
          ),
        ],
      ),
    ),
  );
}

/// Sends a financial entry. Handles server confirmations (over-payment, duplicate attendance)
/// and queues the entry offline when the server is unreachable.
Future<Map<String, dynamic>?> submitEntry(
  BuildContext context, {
  required String path,
  required Map<String, dynamic> body,
  required String label,
  String method = 'POST',
}) async {
  if (method == 'POST') body['client_uuid'] ??= newUuid();
  try {
    final res = await Api.instance.send(method, path, body: body);
    final map = Map<String, dynamic>.from((res as Map?) ?? const {});
    final rec = map['record'] is Map ? map['record'] as Map : map;
    var msg = map['duplicate'] == true ? 'Already saved earlier (${rec['txn_id'] ?? ''}) – no duplicate created.' : '$label saved${rec['txn_id'] != null ? ' · ${rec['txn_id']}' : ''}';
    if (map['split'] is List && (map['split'] as List).isNotEmpty) {
      final s = (map['split'] as List).first as Map;
      msg += ' (excess ${inr(s['amount'])} recorded as advance)';
    }
    showSnack(context, msg);
    return map;
  } on ApiException catch (e) {
    if (e.code == 'overpayment_confirmation_required') {
      final action = await overpaymentDialog(context, e);
      if (action == null) return null;
      return submitEntry(context, path: path, body: {...body, 'overpayment_action': action}, label: label, method: method);
    }
    if (e.code == 'duplicate_work_record') {
      final again = await confirmDialog(context, 'Work already recorded', e.message, ok: 'Add another session');
      if (!again) return null;
      return submitEntry(context, path: path, body: {...body, 'allow_multiple_sessions': true}, label: label, method: method);
    }
    if (e.isNetwork && method == 'POST') {
      await Outbox.instance.add(OutboxItem(id: body['client_uuid'].toString(), method: method, path: path, body: body, label: label));
      showSnack(context, 'No connection – $label saved on this phone and will sync automatically.');
      return {'queued': true};
    }
    showSnack(context, e.message, error: true);
    return null;
  }
}

Future<String?> overpaymentDialog(BuildContext context, ApiException e) {
  final d = e.data;
  final options = (d['options'] as List?)?.map((x) => x.toString()).toList() ?? ['advance', 'other'];
  return showDialog<String>(
    context: context,
    builder: (c) => AlertDialog(
      title: const Text('Payment exceeds outstanding wages'),
      content: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(e.message),
          const SizedBox(height: 12),
          _kv('Outstanding earned wages', inr(d['outstanding_wages'])),
          _kv('Payment amount', inr(d['amount'])),
          _kv('Excess', inr(d['excess'])),
          _kv('Unrecovered advance', inr(d['outstanding_advance'])),
        ]),
      ),
      actionsOverflowDirection: VerticalDirection.down,
      actionsOverflowButtonSpacing: 6,
      actions: [
        if (options.contains('split'))
          FilledButton(onPressed: () => Navigator.pop(c, 'split'), child: Text('Pay ${inr(d['outstanding_wages'])} as wages + ${inr(d['excess'])} as advance')),
        OutlinedButton(onPressed: () => Navigator.pop(c, 'advance'), child: const Text('Record whole amount as advance')),
        OutlinedButton(onPressed: () => Navigator.pop(c, 'other'), child: const Text('Record as other employee payment')),
        TextButton(onPressed: () => Navigator.pop(c), child: const Text('Cancel')),
      ],
    ),
  );
}

Widget _kv(String k, String v) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(children: [Expanded(child: Text(k, style: const TextStyle(color: Colors.black54))), Text(v, style: const TextStyle(fontWeight: FontWeight.w600))]),
    );

class StatCard extends StatelessWidget {
  const StatCard({super.key, required this.title, required this.value, this.subtitle, this.color = brand, this.valueColor});
  final String title;
  final String value;
  final String? subtitle;
  final Color color;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      child: Container(
        decoration: BoxDecoration(border: Border(left: BorderSide(color: color, width: 4))),
        padding: const EdgeInsets.fromLTRB(12, 10, 10, 10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Text(title, style: const TextStyle(fontSize: 12, color: Colors.black54, fontWeight: FontWeight.w600), maxLines: 2, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 4),
          FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(value, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700, color: valueColor))),
          if (subtitle != null) Text(subtitle!, style: const TextStyle(fontSize: 11, color: Colors.black45), maxLines: 2, overflow: TextOverflow.ellipsis),
        ]),
      ),
    );
  }
}

class StatGrid extends StatelessWidget {
  const StatGrid({super.key, required this.children});
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final cols = c.maxWidth > 900 ? 4 : (c.maxWidth > 560 ? 3 : 2);
      final w = (c.maxWidth - (cols - 1) * 8) / cols;
      return Wrap(spacing: 8, runSpacing: 8, children: children.map((x) => SizedBox(width: w, child: x)).toList());
    });
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key});
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(2, 18, 2, 8),
        child: Text(text.toUpperCase(), style: const TextStyle(fontSize: 12, letterSpacing: 1, fontWeight: FontWeight.w700, color: Colors.black54)),
      );
}

class MoneyText extends StatelessWidget {
  const MoneyText(this.value, {super.key, this.style});
  final dynamic value;
  final TextStyle? style;
  @override
  Widget build(BuildContext context) => Text(inr(value), style: (style ?? const TextStyle()).copyWith(color: isNegative(value) ? bad : null, fontFeatures: const [FontFeature.tabularFigures()]));
}

class ErrorView extends StatelessWidget {
  const ErrorView(this.message, {super.key, this.onRetry});
  final String message;
  final VoidCallback? onRetry;
  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.cloud_off, size: 42, color: Colors.black38),
            const SizedBox(height: 8),
            Text(message, textAlign: TextAlign.center),
            if (onRetry != null) Padding(padding: const EdgeInsets.only(top: 12), child: FilledButton.tonal(onPressed: onRetry, child: const Text('Retry'))),
          ]),
        ),
      );
}

/// Searchable picker (employees, categories…). Items need 'id' and 'label', optional 'sub'.
Future<Map<String, dynamic>?> pickItem(BuildContext context, String title, List<Map<String, dynamic>> items) {
  return showModalBottomSheet<Map<String, dynamic>>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (c) {
      var q = '';
      return StatefulBuilder(builder: (c, set) {
        final shown = items.where((i) => '${i['label']} ${i['sub'] ?? ''}'.toLowerCase().contains(q.toLowerCase())).toList();
        return Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(c).viewInsets.bottom),
          child: SizedBox(
            height: MediaQuery.of(c).size.height * 0.75,
            child: Column(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: TextField(
                  autofocus: true,
                  decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: 'Search $title', border: const OutlineInputBorder()),
                  onChanged: (v) => set(() => q = v),
                ),
              ),
              Expanded(
                child: shown.isEmpty
                    ? const Center(child: Text('No matches'))
                    : ListView.builder(
                        itemCount: shown.length,
                        itemBuilder: (c, i) => ListTile(
                          title: Text(shown[i]['label'].toString()),
                          subtitle: shown[i]['sub'] == null ? null : Text(shown[i]['sub'].toString()),
                          onTap: () => Navigator.pop(c, shown[i]),
                        ),
                      ),
              ),
            ]),
          ),
        );
      });
    },
  );
}

/// Read-only field that opens a picker when tapped.
class PickerField extends StatelessWidget {
  const PickerField({super.key, required this.label, required this.text, required this.onTap, this.required = false, this.errorText, this.icon = Icons.arrow_drop_down});
  final String label;
  final String text;
  final VoidCallback onTap;
  final bool required;
  final String? errorText;
  final IconData icon;

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        child: InputDecorator(
          decoration: InputDecoration(labelText: required ? '$label *' : label, border: const OutlineInputBorder(), suffixIcon: Icon(icon), errorText: errorText),
          isEmpty: text.isEmpty,
          child: Text(text),
        ),
      );
}

Future<String?> pickDate(BuildContext context, String? current) async {
  final init = current == null || current.isEmpty ? DateTime.now() : parseYmd(current);
  final d = await showDatePicker(context: context, initialDate: init, firstDate: DateTime(2000), lastDate: DateTime(2100), helpText: 'Select date');
  return d == null ? null : ymd(d);
}

class StatusChip extends StatelessWidget {
  const StatusChip(this.text, {super.key, this.color = brand});
  final String text;
  final Color color;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
        decoration: BoxDecoration(color: color.withAlpha(30), borderRadius: BorderRadius.circular(12)),
        child: Text(text, style: TextStyle(color: color, fontSize: 11.5, fontWeight: FontWeight.w600)),
      );
}

Color statusColor(String s) {
  switch (s) {
    case 'sent':
    case 'delivered':
    case 'read':
    case 'verified':
    case 'active':
      return good;
    case 'failed':
    case 'reversed':
    case 'corrupt':
      return bad;
    case 'manual_required':
    case 'initiated':
    case 'pending':
    case 'inactive':
      return warn;
    default:
      return brand;
  }
}
