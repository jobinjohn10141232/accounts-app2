import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Holds the login session and app-lock settings. Everything is persisted in
/// Android encrypted storage (EncryptedSharedPreferences backed by the Android Keystore).
/// No passwords or server secrets are ever stored – only the revocable API token.
class Session extends ChangeNotifier {
  Session._();
  static final Session instance = Session._();

  static const FlutterSecureStorage _store = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  String? site;
  String? token;
  Map<String, dynamic> user = {};
  int idleMinutes = 30;
  bool biometricEnabled = false;
  bool pinSet = false;
  bool unlocked = false;
  DateTime lastActive = DateTime.now();

  bool get loggedIn => token != null && site != null;

  String get apiBase {
    final s = (site ?? '').replaceAll(RegExp(r'/+$'), '');
    return '$s/wp-json/pam/v1/';
  }

  Future<void> load() async {
    site = await _store.read(key: 'site');
    token = await _store.read(key: 'token');
    final u = await _store.read(key: 'user');
    user = u == null ? {} : (jsonDecode(u) as Map<String, dynamic>);
    idleMinutes = int.tryParse(await _store.read(key: 'idle') ?? '') ?? 30;
    biometricEnabled = (await _store.read(key: 'bio')) == '1';
    pinSet = (await _store.read(key: 'pin_hash')) != null;
    notifyListeners();
  }

  /// Validates and normalises the website address. Release builds require HTTPS.
  static String normaliseSite(String input) {
    var s = input.trim();
    if (!s.startsWith('http://') && !s.startsWith('https://')) s = 'https://$s';
    s = s.replaceAll(RegExp(r'/+$'), '');
    if (s.endsWith('/wp-json/pam/v1')) s = s.substring(0, s.length - '/wp-json/pam/v1'.length);
    final uri = Uri.tryParse(s);
    if (uri == null || uri.host.isEmpty) throw const FormatException('Enter a valid website address.');
    if (uri.scheme != 'https' && kReleaseMode) {
      throw const FormatException('For security the app only connects over HTTPS.');
    }
    return s;
  }

  Future<void> setSite(String s) async {
    site = s;
    await _store.write(key: 'site', value: s);
  }

  Future<void> saveLogin(String t, Map<String, dynamic> u, int idle) async {
    token = t;
    user = u;
    idleMinutes = idle;
    unlocked = true;
    lastActive = DateTime.now();
    await _store.write(key: 'token', value: t);
    await _store.write(key: 'user', value: jsonEncode(u));
    await _store.write(key: 'idle', value: idle.toString());
    notifyListeners();
  }

  /// Logs out locally. Cached financial data is removed; unsynced entries are kept
  /// unless [wipeOutbox] is true (they are never silently discarded).
  Future<void> clearLogin({bool wipeCache = true}) async {
    token = null;
    unlocked = false;
    await _store.delete(key: 'token');
    if (wipeCache) {
      final all = await _store.readAll();
      for (final k in all.keys) {
        if (k.startsWith('cache_')) await _store.delete(key: k);
      }
    }
    notifyListeners();
  }

  void touch() => lastActive = DateTime.now();

  bool get idleExpired => DateTime.now().difference(lastActive).inMinutes >= idleMinutes;

  void lock() {
    unlocked = false;
    notifyListeners();
  }

  void unlock() {
    unlocked = true;
    lastActive = DateTime.now();
    notifyListeners();
  }

  /* ---------------- PIN / biometric app lock ---------------- */

  String _hash(String salt, String pin) => sha256.convert(utf8.encode('$salt:$pin')).toString();

  Future<void> setPin(String pin) async {
    final rnd = Random.secure();
    final salt = base64Url.encode(List<int>.generate(16, (_) => rnd.nextInt(256)));
    await _store.write(key: 'pin_salt', value: salt);
    await _store.write(key: 'pin_hash', value: _hash(salt, pin));
    await _store.write(key: 'pin_fail', value: '0');
    pinSet = true;
    notifyListeners();
  }

  Future<void> removePin() async {
    await _store.delete(key: 'pin_hash');
    await _store.delete(key: 'pin_salt');
    pinSet = false;
    biometricEnabled = false;
    await _store.write(key: 'bio', value: '0');
    notifyListeners();
  }

  /// Returns true if correct. After 5 wrong PINs the session is cleared (password login required).
  Future<bool> checkPin(String pin) async {
    final salt = await _store.read(key: 'pin_salt');
    final hash = await _store.read(key: 'pin_hash');
    if (salt == null || hash == null) return false;
    if (_hash(salt, pin) == hash) {
      await _store.write(key: 'pin_fail', value: '0');
      return true;
    }
    final fails = (int.tryParse(await _store.read(key: 'pin_fail') ?? '0') ?? 0) + 1;
    await _store.write(key: 'pin_fail', value: fails.toString());
    if (fails >= 5) {
      await clearLogin();
    }
    return false;
  }

  Future<void> setBiometric(bool on) async {
    biometricEnabled = on;
    await _store.write(key: 'bio', value: on ? '1' : '0');
    notifyListeners();
  }

  /* ---------------- Encrypted offline cache ---------------- */

  Future<void> cachePut(String key, Object? value) async {
    await _store.write(key: 'cache_$key', value: jsonEncode(value));
  }

  Future<dynamic> cacheGet(String key) async {
    final v = await _store.read(key: 'cache_$key');
    if (v == null) return null;
    try {
      return jsonDecode(v);
    } catch (_) {
      return null;
    }
  }

  Future<String?> rawRead(String key) => _store.read(key: key);
  Future<void> rawWrite(String key, String value) => _store.write(key: key, value: value);
}
