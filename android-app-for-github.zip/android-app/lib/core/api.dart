import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

import 'session.dart';

class ApiException implements Exception {
  ApiException(this.status, this.code, this.message, [Map<String, dynamic>? data]) : data = data ?? const {};

  final int status;
  final String code;
  final String message;
  final Map<String, dynamic> data;

  /// True when the server could not be reached (offline / timeout) – safe to queue.
  bool get isNetwork => status == 0;

  @override
  String toString() => message;
}

/// REST client for the Personal Accounts Manager WordPress plugin (namespace pam/v1).
/// Only an opaque, revocable bearer token is sent – never passwords or server secrets.
class Api {
  Api._();
  static final Api instance = Api._();

  final http.Client _client = http.Client();

  /// Called on HTTP 401 (expired / revoked session).
  void Function()? onUnauthorized;

  Uri _uri(String path, [Map<String, dynamic>? query]) {
    final u = Uri.parse(Session.instance.apiBase + path);
    if (query == null) return u;
    final q = <String, String>{...u.queryParameters};
    query.forEach((k, v) {
      if (v != null && v.toString().isNotEmpty) q[k] = v.toString();
    });
    return u.replace(queryParameters: q.isEmpty ? null : q);
  }

  Future<dynamic> get(String path, [Map<String, dynamic>? query]) => send('GET', path, query: query);
  Future<dynamic> post(String path, [Object? body]) => send('POST', path, body: body ?? const <String, dynamic>{});
  Future<dynamic> put(String path, [Object? body]) => send('PUT', path, body: body ?? const <String, dynamic>{});
  Future<dynamic> delete(String path) => send('DELETE', path);

  Future<dynamic> send(String method, String path, {Map<String, dynamic>? query, Object? body, bool auth = true}) async {
    final req = http.Request(method, _uri(path, query));
    req.headers['Accept'] = 'application/json';
    final token = Session.instance.token;
    if (auth && token != null) {
      req.headers['Authorization'] = 'Bearer $token';
      req.headers['X-PAM-Token'] = token; // fallback for hosts that strip Authorization
    }
    if (body != null) {
      req.headers['Content-Type'] = 'application/json';
      req.body = jsonEncode(body);
    }
    http.Response res;
    try {
      final streamed = await _client.send(req).timeout(const Duration(seconds: 60));
      res = await http.Response.fromStream(streamed);
    } on TimeoutException {
      throw ApiException(0, 'network', 'The server did not respond in time. Check your connection.');
    } on HandshakeException {
      throw ApiException(0, 'tls', 'Secure (HTTPS) connection failed. Check the website certificate.');
    } on SocketException {
      throw ApiException(0, 'network', 'No internet connection or the server is unreachable.');
    } on http.ClientException catch (e) {
      throw ApiException(0, 'network', 'Network error: ${e.message}');
    }
    Session.instance.touch();
    dynamic json;
    try {
      json = res.bodyBytes.isEmpty ? null : jsonDecode(utf8.decode(res.bodyBytes));
    } catch (_) {
      json = null;
    }
    if (res.statusCode >= 200 && res.statusCode < 300) return json;
    final map = json is Map<String, dynamic> ? json : <String, dynamic>{};
    final data = map['data'] is Map<String, dynamic> ? map['data'] as Map<String, dynamic> : <String, dynamic>{};
    final ex = ApiException(
      res.statusCode,
      (map['code'] ?? 'http_${res.statusCode}').toString(),
      (map['message'] ?? 'Request failed (HTTP ${res.statusCode}).').toString(),
      data,
    );
    if (res.statusCode == 401 && auth) onUnauthorized?.call();
    throw ex;
  }

  Future<Map<String, dynamic>> login(String site, String login, String password) async {
    await Session.instance.setSite(site);
    final res = await send('POST', 'auth/login', body: {'login': login, 'password': password, 'device_name': 'Android app'}, auth: false);
    return Map<String, dynamic>.from(res as Map);
  }

  /// Downloads a (signed or authenticated) file URL into the app's private cache.
  Future<File> download(String url, String fileName) async {
    final headers = <String, String>{};
    final token = Session.instance.token;
    if (token != null) {
      headers['Authorization'] = 'Bearer $token';
      headers['X-PAM-Token'] = token;
    }
    final http.Response res;
    try {
      res = await _client.get(Uri.parse(url), headers: headers).timeout(const Duration(seconds: 120));
    } on Exception {
      throw ApiException(0, 'network', 'Download failed – check your connection.');
    }
    if (res.statusCode != 200) {
      throw ApiException(res.statusCode, 'download_failed', 'Download failed (HTTP ${res.statusCode}).');
    }
    final dir = await getTemporaryDirectory();
    final safe = fileName.replaceAll(RegExp(r'[^A-Za-z0-9._\-]'), '_');
    final f = File('${dir.path}/$safe');
    await f.writeAsBytes(res.bodyBytes, flush: true);
    return f;
  }

  Future<Map<String, dynamic>> uploadAttachment(File file) async {
    final req = http.MultipartRequest('POST', _uri('attachments'));
    final token = Session.instance.token;
    if (token != null) {
      req.headers['Authorization'] = 'Bearer $token';
      req.headers['X-PAM-Token'] = token;
    }
    req.headers['Accept'] = 'application/json';
    req.files.add(await http.MultipartFile.fromPath('file', file.path));
    final res = await http.Response.fromStream(await _client.send(req).timeout(const Duration(seconds: 120)));
    final body = res.bodyBytes.isEmpty ? <String, dynamic>{} : jsonDecode(utf8.decode(res.bodyBytes));
    if (res.statusCode >= 300) {
      throw ApiException(res.statusCode, 'upload_failed', (body is Map && body['message'] != null) ? body['message'].toString() : 'Upload failed.');
    }
    return Map<String, dynamic>.from(body as Map);
  }
}
