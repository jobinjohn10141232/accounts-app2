/// Formatting helpers. Amounts arrive from the server as exact decimal strings
/// ("1234.50"); the app never does balance arithmetic itself – all balances come from
/// the server's single accounting service so web, Android and Excel always match.
library;

/// Indian currency format: "1234567.5" -> "₹12,34,567.50".
String inr(dynamic value, {bool symbol = true}) {
  if (value == null || value.toString().isEmpty) return '';
  var s = value.toString().replaceAll(',', '').trim();
  final neg = s.startsWith('-');
  if (neg) s = s.substring(1);
  final parts = s.split('.');
  var intPart = parts[0].isEmpty ? '0' : parts[0];
  var frac = parts.length > 1 ? parts[1] : '';
  frac = (frac + '00').substring(0, 2);
  intPart = intPart.replaceFirst(RegExp(r'^0+(?=\d)'), '');
  String grouped;
  if (intPart.length <= 3) {
    grouped = intPart;
  } else {
    final last3 = intPart.substring(intPart.length - 3);
    var rest = intPart.substring(0, intPart.length - 3);
    final buf = <String>[];
    while (rest.length > 2) {
      buf.insert(0, rest.substring(rest.length - 2));
      rest = rest.substring(0, rest.length - 2);
    }
    if (rest.isNotEmpty) buf.insert(0, rest);
    grouped = '${buf.join(',')},$last3';
  }
  return '${neg ? '-' : ''}${symbol ? '₹' : ''}$grouped.$frac';
}

/// "2026-10-04" -> "04-10-2026"
String dmy(dynamic ymd) {
  if (ymd == null) return '';
  final m = RegExp(r'^(\d{4})-(\d{2})-(\d{2})').firstMatch(ymd.toString());
  if (m == null) return ymd.toString();
  return '${m.group(3)}-${m.group(2)}-${m.group(1)}';
}

String ymd(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

DateTime parseYmd(String s) {
  final m = RegExp(r'^(\d{4})-(\d{2})-(\d{2})').firstMatch(s);
  if (m == null) return DateTime.now();
  return DateTime(int.parse(m.group(1)!), int.parse(m.group(2)!), int.parse(m.group(3)!));
}

String todayYmd() => ymd(DateTime.now());

String qty(dynamic v) {
  if (v == null || v.toString().isEmpty) return '';
  final d = double.tryParse(v.toString());
  return d == null ? v.toString() : d.toStringAsFixed(2);
}

double num0(dynamic v) => double.tryParse((v ?? '0').toString()) ?? 0;

bool isNegative(dynamic v) => num0(v) < 0;

/// Validates an amount entered by the user (max 2 decimals).
bool validAmount(String s, {bool allowNegative = false}) {
  final re = allowNegative ? RegExp(r'^-?\d{1,12}(\.\d{1,2})?$') : RegExp(r'^\d{1,12}(\.\d{1,2})?$');
  return re.hasMatch(s.trim());
}

const Map<String, String> workStatusLabels = {
  'full': 'Full day',
  'half': 'Half day',
  'custom': 'Custom fraction',
  'absent': 'Absent',
  'paid_leave': 'Paid leave',
};
const Map<String, String> paymentTypeLabels = {
  'wage': 'Regular wage payment',
  'advance': 'Advance payment',
  'final_settlement': 'Final settlement',
  'other': 'Other employee payment',
};
const Map<String, String> methodLabels = {'cash': 'Cash', 'bank': 'Bank transfer', 'upi': 'UPI', 'other': 'Other'};
const Map<String, String> recoveryLabels = {
  'wage_offset': 'Recovered from wages',
  'cash_repayment': 'Repaid in cash',
};
