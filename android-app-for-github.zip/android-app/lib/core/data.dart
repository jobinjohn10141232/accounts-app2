import 'package:flutter/foundation.dart';

import 'api.dart';
import 'session.dart';

/// Reference data (employees, categories, accounts, settings) with an encrypted offline copy.
class AppData extends ChangeNotifier {
  AppData._();
  static final AppData instance = AppData._();

  Map<String, dynamic> meta = {};
  bool fromCache = false;

  List<Map<String, dynamic>> _list(String k) =>
      ((meta[k] as List?) ?? const []).map((e) => Map<String, dynamic>.from(e as Map)).toList();

  List<Map<String, dynamic>> employees({bool includeInactive = false}) =>
      _list('employees').where((e) => includeInactive || e['status'] == 'active').toList();

  List<Map<String, dynamic>> categories(String type, {bool includeInactive = false}) =>
      _list('categories').where((c) => c['category_type'] == type && (includeInactive || c['status'] == 'active')).toList();

  List<Map<String, dynamic>> accounts({bool includeInactive = false}) =>
      _list('accounts').where((a) => includeInactive || a['status'] == 'active').toList();

  Map<String, dynamic> get settings => Map<String, dynamic>.from((meta['settings'] as Map?) ?? const {});

  Map<String, String> get reports => Map<String, String>.from(((meta['reports'] as Map?) ?? const {}).map((k, v) => MapEntry(k.toString(), v.toString())));

  Map<String, String> get scopes => Map<String, String>.from(((meta['scopes'] as Map?) ?? const {}).map((k, v) => MapEntry(k.toString(), v.toString())));

  String get today => (meta['today'] ?? '').toString();

  Map<String, dynamic>? employee(dynamic id) {
    for (final e in _list('employees')) {
      if (e['id'].toString() == id.toString()) return e;
    }
    return null;
  }

  int? defaultAccountFor(String method) {
    for (final a in accounts()) {
      if (a['account_type'] == method) return int.tryParse(a['id'].toString());
    }
    return null;
  }

  Future<void> load() async {
    try {
      final m = await Api.instance.get('meta');
      meta = Map<String, dynamic>.from(m as Map);
      fromCache = false;
      await Session.instance.cachePut('meta', meta);
    } on ApiException catch (e) {
      if (!e.isNetwork) rethrow;
      final c = await Session.instance.cacheGet('meta');
      if (c is Map) {
        meta = Map<String, dynamic>.from(c);
        fromCache = true;
      } else {
        rethrow;
      }
    }
    notifyListeners();
  }
}
