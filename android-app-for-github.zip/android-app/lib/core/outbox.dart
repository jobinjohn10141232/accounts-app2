import 'dart:convert';

import 'package:flutter/foundation.dart';

import 'api.dart';
import 'session.dart';

/// One financial entry waiting to be sent to the server.
class OutboxItem {
  OutboxItem({
    required this.id,
    required this.method,
    required this.path,
    required this.body,
    required this.label,
    DateTime? createdAt,
    this.status = 'pending',
    this.error,
    this.attempts = 0,
    this.errorCode,
  }) : createdAt = createdAt ?? DateTime.now();

  /// The client_uuid – also sent to the server, which makes every replay idempotent.
  final String id;
  final String method;
  final String path;
  Map<String, dynamic> body;
  final String label;
  final DateTime createdAt;

  /// pending | attention (server rejected it – needs the user's decision)
  String status;
  String? error;
  String? errorCode;
  int attempts;

  Map<String, dynamic> toJson() => {
        'id': id,
        'method': method,
        'path': path,
        'body': body,
        'label': label,
        'created_at': createdAt.toIso8601String(),
        'status': status,
        'error': error,
        'error_code': errorCode,
        'attempts': attempts,
      };

  factory OutboxItem.fromJson(Map<String, dynamic> j) => OutboxItem(
        id: j['id'] as String,
        method: j['method'] as String,
        path: j['path'] as String,
        body: Map<String, dynamic>.from(j['body'] as Map),
        label: (j['label'] ?? '') as String,
        createdAt: DateTime.tryParse((j['created_at'] ?? '') as String) ?? DateTime.now(),
        status: (j['status'] ?? 'pending') as String,
        error: j['error'] as String?,
        errorCode: j['error_code'] as String?,
        attempts: (j['attempts'] ?? 0) as int,
      );
}

/// Reliable offline queue for financial entries.
///  * Stored encrypted on the device (Android Keystore backed).
///  * Sent in FIFO order; each carries a client_uuid so the server ignores duplicates.
///  * Network failures leave items pending; server rejections (validation, duplicate
///    attendance, over-payment confirmation) are flagged for the user – never dropped.
///  * Items are only removed after the server confirms them, or when the user explicitly
///    discards one.
class Outbox extends ChangeNotifier {
  Outbox._();
  static final Outbox instance = Outbox._();

  List<OutboxItem> items = [];
  bool syncing = false;
  DateTime? lastSync;
  String? lastError;

  int get pendingCount => items.where((i) => i.status == 'pending').length;
  int get attentionCount => items.where((i) => i.status == 'attention').length;

  Future<void> load() async {
    final raw = await Session.instance.rawRead('outbox');
    if (raw != null) {
      try {
        final list = jsonDecode(raw) as List;
        items = list.map((e) => OutboxItem.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      } catch (_) {
        // Keep the raw copy for manual recovery rather than losing it.
        await Session.instance.rawWrite('outbox_corrupt_${DateTime.now().millisecondsSinceEpoch}', raw);
        items = [];
      }
    }
    notifyListeners();
  }

  Future<void> _save() async {
    await Session.instance.rawWrite('outbox', jsonEncode(items.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  Future<void> add(OutboxItem item) async {
    if (items.any((i) => i.id == item.id)) return;
    items.add(item);
    await _save();
  }

  /// Sends pending items. Returns number successfully synced.
  Future<int> sync() async {
    if (syncing || !Session.instance.loggedIn) return 0;
    syncing = true;
    lastError = null;
    notifyListeners();
    var done = 0;
    try {
      for (final item in List<OutboxItem>.from(items)) {
        if (item.status != 'pending') continue;
        item.attempts++;
        try {
          await Api.instance.send(item.method, item.path, body: item.body);
          items.removeWhere((i) => i.id == item.id);
          done++;
          await _save();
        } on ApiException catch (e) {
          if (e.isNetwork || e.status >= 500 || e.status == 401) {
            lastError = e.message;
            await _save();
            break; // keep order; retry later
          }
          item.status = 'attention';
          item.error = e.message;
          item.errorCode = e.code;
          await _save();
        }
      }
      lastSync = DateTime.now();
    } finally {
      syncing = false;
      notifyListeners();
    }
    return done;
  }

  /// Re-queue an item (optionally with extra fields such as overpayment_action).
  Future<void> retry(String id, {Map<String, dynamic>? extra}) async {
    final item = items.firstWhere((i) => i.id == id);
    if (extra != null) item.body = {...item.body, ...extra};
    item.status = 'pending';
    item.error = null;
    item.errorCode = null;
    await _save();
    await sync();
  }

  /// Explicit user decision only.
  Future<void> discard(String id) async {
    items.removeWhere((i) => i.id == id);
    await _save();
  }
}
