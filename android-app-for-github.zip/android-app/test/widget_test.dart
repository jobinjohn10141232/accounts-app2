import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:personal_accounts_manager/widgets/common.dart';
import 'package:personal_accounts_manager/widgets/report_view.dart';

void main() {
  testWidgets('StatCard shows title and value', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: Scaffold(body: StatCard(title: 'Outstanding wages', value: '₹400.00'))));
    expect(find.text('Outstanding wages'), findsOneWidget);
    expect(find.text('₹400.00'), findsOneWidget);
  });

  testWidgets('ReportView renders server table with totals', (tester) async {
    final table = <String, dynamic>{
      'columns': [
        {'key': 'employee_name', 'label': 'Employee', 'type': 'text'},
        {'key': 'earned', 'label': 'Earned', 'type': 'money'},
      ],
      'rows': [
        {'employee_name': 'Rajesh', 'earned': '2400.00'},
      ],
      'totals': {'earned': '2400.00'},
      'summary': [],
    };
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: SingleChildScrollView(child: ReportView(table)))));
    expect(find.text('Rajesh'), findsOneWidget);
    expect(find.text('TOTAL'), findsOneWidget);
    expect(find.text('₹2,400.00'), findsNWidgets(2));
  });
}
