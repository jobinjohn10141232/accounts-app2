import 'package:flutter_test/flutter_test.dart';
import 'package:personal_accounts_manager/core/format.dart';
import 'package:personal_accounts_manager/core/outbox.dart';

void main() {
  group('Indian currency formatting', () {
    test('groups lakhs and crores', () {
      expect(inr('1234567.5'), '₹12,34,567.50');
      expect(inr('100000'), '₹1,00,000.00');
      expect(inr('999'), '₹999.00');
      expect(inr('12345678.9'), '₹1,23,45,678.90');
    });
    test('negative and zero values', () {
      expect(inr('-400'), '-₹400.00');
      expect(inr('0'), '₹0.00');
      expect(inr('0.5'), '₹0.50');
    });
    test('no symbol option', () {
      expect(inr('2400', symbol: false), '2,400.00');
    });
  });

  group('Dates', () {
    test('ISO to DD-MM-YYYY', () {
      expect(dmy('2026-10-04'), '04-10-2026');
      expect(ymd(DateTime(2026, 1, 5)), '2026-01-05');
      expect(parseYmd('2026-10-04'), DateTime(2026, 10, 4));
    });
  });

  group('Amount validation', () {
    test('accepts up to 2 decimals', () {
      expect(validAmount('800'), isTrue);
      expect(validAmount('800.5'), isTrue);
      expect(validAmount('800.55'), isTrue);
      expect(validAmount('800.555'), isFalse);
      expect(validAmount('-5'), isFalse);
      expect(validAmount('-5', allowNegative: true), isTrue);
      expect(validAmount('abc'), isFalse);
    });
  });

  group('Offline outbox item', () {
    test('round-trips through JSON without losing data', () {
      final item = OutboxItem(id: 'uuid-1', method: 'POST', path: 'payments', body: {'amount': '500', 'employee_id': 3, 'txn_date': '2026-10-02'}, label: 'Employee payment');
      final back = OutboxItem.fromJson(item.toJson());
      expect(back.id, 'uuid-1');
      expect(back.body['amount'], '500');
      expect(back.status, 'pending');
      expect(back.label, 'Employee payment');
    });
  });
}
